package ch3;

import java.util.Arrays;

public class MergeSort {
	static int length;
	public static void main(String[] args) {
		int[] a = {0, 29, 24, 16, 3, 3, 3, 29, 27, 16};
		length = a.length;
		System.out.println("Before: " + Arrays.toString(a));
		mergeSort (a, 0, length - 1);
		System.out.println("After: " + Arrays.toString(a));
	}

	private static void mergeSort(int[] a, int start, int end) {
		if (end <= start) return;
		
		int mid = (start + end) / 2;
		mergeSort(a, start, mid);
		mergeSort(a, mid + 1, end);
		
		merge(a, start, mid, end);
	}
	
	private static void merge(int[] a, int start, int mid, int end) {
		int start1 = start, end1 = mid;
		int start2 = mid + 1, end2 = end;
		int[] tmpArray = new int[length];
		int tmpIdx = start;
		
		// copy in sorted order
		while (start1 <= end1 && start2 <= end2) {
			if (a[start1] < a[start2])
				tmpArray[tmpIdx++] = a[start1++];
			else 
				tmpArray[tmpIdx++] = a[start2++];
		}
		
		// copy left array's leftover
		while (start1 <= end1)
			tmpArray[tmpIdx++] = a[start1++];
		
		// copy right array's leftover
		while (start2 <= end2)
			tmpArray[tmpIdx++] = a[start2++];
		
		//copy from tmp array to original array
		for (int i = start; i <= end; i++)
			a[i] = tmpArray[i];
	}
}