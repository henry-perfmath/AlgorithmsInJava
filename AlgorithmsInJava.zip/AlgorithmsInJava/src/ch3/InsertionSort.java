package ch3;

import java.util.Arrays;

public class InsertionSort {
	public static void main(String[] args) {
		int[] a = {0, 29, 24, 16, 3, 3, 3, 29, 27, 16};
		System.out.println("Before: " + Arrays.toString(a));
		//insertionSort1 (a);
		insertionSort (a);
		System.out.println("After: " + Arrays.toString(a));
	}

	private static void insertionSort(int[] a) {
		int n = a.length;
		for (int i = 1; i < n; i++) {
			int j = i;
			int currItem = a[j];
			
			//1. look backward
			while (j > 0 && a[j - 1] > currItem) {
				a[j] = a [j - 1];
				--j;
			}
			
			//2. update
			a[j] = currItem;
		}
	}
	
	
	private static void insertionSort0(int[] a) {
		int n = a.length;
		for (int i = 1; i < n; i++) {
			int j = i;
			while (j > 0 && a[j - 1] > a[j]) {
				int tmp = a[j];
				a[j] = a [j - 1];
				a[j - 1] = tmp;
				--j;
			}
		}
	}
}
