package ch3;

import java.util.Arrays;

public class QuickSort {
	public static void main(String[] args) {
		int[] a = {0, 29, 24, 16, 3, 3, 3, 29, 27, 16};
		System.out.println("Before: " + Arrays.toString(a));
		quickSort (a, 0, a.length - 1);
		System.out.println("After: " + Arrays.toString(a));
	}
	
	static int swap(int... args) {
		return args[0];
	}
	private static int partition(int[] a, int start, int end) {
		int pivot = start;
		while (start < end) {
			while (start < end && a[start] <= a[pivot])
				start++;
			while (a[end] > a[pivot]) {
				end--;
			}
			if (start < end)
				a[start] = swap(a[end], a[end] = a [start]);
		}

		a[end] = swap(a[pivot], a[pivot] = a[end]);
		return end;
	}

	private static void quickSort(int[] a, int start, int end) {
		if (end <= start)
			return; // exit condition
		int pivot = partition(a, start, end);
		quickSort(a, start, pivot - 1);
		quickSort(a, pivot + 1, end);
	}
}