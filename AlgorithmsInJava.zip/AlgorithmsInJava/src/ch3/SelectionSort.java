package ch3;

import java.util.Arrays;

public class SelectionSort {
	public static void main(String[] args) {
		int[] a = {0, 29, 24, 16, 3, 3, 3, 29, 27, 16};
		System.out.println("Before: " + Arrays.toString(a));
		selectionSort (a);
		System.out.println("After: " + Arrays.toString(a));
	}
	
	private static void selectionSort(int[] a) {
		int n = a.length;
		for (int i = 0; i < n - 1; i++) {
			
			//1. look forward for minIndex
			int minIndex = i;
			
			int j = i + 1;
			while (j < n) {
				if (a[j] < a[minIndex]) {
					minIndex = j;
				}
				j++;
			}
			
			 //2. update if needed 
			if (a[minIndex] < a[i]) {
				int tmp = a[i];
				a[i] = a[minIndex];
				a[minIndex] = tmp;
			}
		}
	}
}