package ch6;

public class LinkedList {
	private Node head; // no external access
	
	public LinkedList() {
		super();
	}

	// returns the element at the specified position in this list.
	Node get(int index) {
		if (index < 0 || index > size())  {
			try{
	            throw new IndexOutOfBoundsException();
	       } catch (IndexOutOfBoundsException e) {
	            e.printStackTrace();
	            return null;
	       }
		}

		//if (index == 0) return head;
		
		Node cursor = head;
		int count = 0;

		while (cursor != null && count < index) {
			count++;
			cursor = cursor.next;
		}
		return cursor;
	}
	
	// add to the end of list
	void add(Node node) {
		Node cursor = head;
		if (cursor == null) {
			head = node;
		} else {
			while (cursor.next != null) {
				cursor = cursor.next;
			}
			cursor.next = node;
		}
	}
	
	// inserts the specified element at the specified position in this list.
	void add(int index, Node node) {
		if (index < 0 || index >= size())  {
			try{
	            throw new IndexOutOfBoundsException();
	       } catch (IndexOutOfBoundsException e) {
	            e.printStackTrace();
	            return;
	       }
		}
	
		Node cursor = head;
		int count = 0;
		Node prev = null;
		while (cursor != null && count < index) {
			prev = cursor;
			cursor = cursor.next;
			count++;
		}
		prev.next = node;
		node.next = cursor;
	}
	
	// replaces the element at the specified position in this list 
	// with the specified element.
	void set(int index, Node node) { 
		if (index < 0 || index >= size())  {
			try{
	            throw new IndexOutOfBoundsException();
	       } catch (IndexOutOfBoundsException e) {
	            e.printStackTrace();
	            return;
	       }
		}
	
		int count = 0;
		Node cursor = head;
		Node prev = null;
		while (cursor != null && count < index) {
			prev = cursor;
			count++;
			cursor = cursor.next;
		}
		prev.next = node;
		node.next = cursor.next;
	}
	
	// retrieves and removes the head (first element) of this list
	Node remove() { 
		
		Node cursor = head;
		if (cursor == null) {
			throw new NullPointerException("empty list");
		} else {
			head = head.next;
			return cursor;
		}
	}
	
	// removes the element at the specified position in the list.
	void remove(int index) { 
		if (index < 0 || index >= size())  {
			try{
	            throw new IndexOutOfBoundsException();
	       } catch (IndexOutOfBoundsException e) {
	            e.printStackTrace();
	            return;
	       }
		}
	
		int count = 0;
		Node cursor = head;
		Node prev = null;
		while (cursor != null && count < index) {
			prev = cursor;
			cursor = cursor.next;
			count++;
		}
		prev.next = cursor.next;
	}
	
	// Returns of elements in the list.
	int size() {
		int count = 0;
		Node cursor = head;
		while (cursor != null) {
			count++;
			cursor = cursor.next;
		}
		return count;
	}
	
	void traverse() {
		Node cursor = head;
		int count = 0;
		System.out.print("traverse: ");
		while (cursor != null) {
			if (count > 0) System.out.print(",");
			count++;
			System.out.print(cursor.getElement().getData());
			cursor = cursor.next;
		}
		System.out.println( ". size = " + size());
	}
	
	//removes all of the elements from this list.
	void clear() {
		while (head != null) {
			head = head.next;
		}
	}
	
	void clearFirstN(int n) {
		if (n < 0 || n > size())  {
			try{
	            throw new IndexOutOfBoundsException();
	       } catch (IndexOutOfBoundsException e) {
	            e.printStackTrace();
	            return;
	       }
		}

		int count = 0;
		while (head != null && count < n) {
			head = head.next;
			count++;
		}
	}
}
