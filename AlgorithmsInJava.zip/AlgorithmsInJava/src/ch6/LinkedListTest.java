package ch6;

public class LinkedListTest {
	public static void main(String[] args) {
		int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		LinkedList list = new LinkedList();
		for (int i = 0; i < a.length; i++) {
			Element item = new Element (a[i]);
			Node node = new Node(item);
			list.add(node);
		}
		System.out.print ("traverse (initial): ");
		list.traverse();
		
		System.out.print ("add 99 at index = 3: ");
		list.add(3, new Node(new Element(99)));
		list.traverse();
		
		System.out.print ("remove (fisrt): ");
		list.remove();
		list.traverse();
		
		System.out.print ("remove at index = 3: ");
		list.remove(3);
		list.traverse();
		
		System.out.print ("set to 99 at index = 3: ");
		list.set(3, new Node(new Element(99)));
		list.traverse();
		
		System.out.print("get " + list.get(1).getElement().getData() + " at index = 1: " );
		list.traverse();
		
		System.out.print ("clearFirstN: (3)");
		list.clearFirstN(3);
		list.traverse();
		
		System.out.print ("clear (all): ");
		list.clear();
		list.traverse();

	}
}
