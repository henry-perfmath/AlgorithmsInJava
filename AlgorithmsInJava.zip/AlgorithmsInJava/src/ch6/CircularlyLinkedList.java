package ch6;

public class CircularlyLinkedList {
	static LinkedList list; 
	
	public void fold(int position) {
		int count = 1;
		Node cursor = list.get(0);
		Node prev = null;

		// 1. find where to fold
		while (cursor.next != null) {
			if (count == position) {
				prev = cursor;
				System.out.println("folding at " + cursor.getElement().getData());
			} 
			cursor = cursor.next;
			count++;
		}
		
		//2. fold		
		cursor.next = prev;
	}
	
	public void checkCircularLinkedList(Node head) {
		list = new LinkedList();
		// seg 0: declare fast and slow walkers
		Node slow = head;
		Node fast = slow;
		
		// seg 1: move both walkers. break if they meet
		while (fast != null && fast.next != null) {
			slow = slow.next;
			fast = fast.next;
			fast = fast.next;
			if (slow == fast) break;
		}
		
		// seg 2: no loop if fast or fast.next null
		if (fast == null || fast.next == null)
			return;
		
		int meetPoint = slow.getElement().getData();
		System.out.println("circular linked list meet-point: " + meetPoint);
		
		// seg 3: find entry point for circular linked list
		System.out.println("find entry point for circular linked list:");
		slow = head; // set slow point back
		while (slow != fast) {
			slow = slow.next;
			fast = fast.next;
		}
		
		int entry = fast.getElement().getData();
		System.out.println("circular linked list enrty: " + entry);
	}
	
	public static void main(String[] args) {
		CircularlyLinkedList ccl = new CircularlyLinkedList();
		list = new LinkedList();
		
		int SIZE = 19;
		for (int i = 0; i < SIZE; i++) {
			list.add(new Node(new Element(i + 1)));
		}
		
		list.traverse();
		System.out.println("save head of the list before folding: ");
		Node head = list.get(0);

		ccl.fold(12);
		
		System.out.println("calling checkCircularLinkedList");
		//list.traverse();
		ccl.checkCircularLinkedList(head);
		//list.clear();
	}
}
