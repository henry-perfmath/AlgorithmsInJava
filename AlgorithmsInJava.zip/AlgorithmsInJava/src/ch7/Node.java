package ch7;

public class Node {
	Element element;
	Node next;
	public Node(Element element) {
		super();
		this.element = element;
	}
	public Element getElement() {
		return element;
	}
	public void setElement(Element element) {
		this.element = element;
	}
}
