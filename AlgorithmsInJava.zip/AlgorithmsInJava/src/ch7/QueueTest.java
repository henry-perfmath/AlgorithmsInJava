package ch7;

public class QueueTest {
	public static void main(String[] args) {
		Queue queue = new Queue();

		queue.add(new Node(new Element(10)));
		queue.add(new Node(new Element(20)));
		queue.add(new Node(new Element(30)));
		queue.add(new Node(new Element(40)));
		
		queue.traverse();
		
		Node node = queue.peek();
		System.out.println("after peek: " + node.getElement().getData());
		queue.traverse();
		
		queue.remove();
		System.out.println("after remove: " + node.getElement().getData());
		queue.traverse();
	}
}
