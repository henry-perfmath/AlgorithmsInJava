package ch7;

public class Queue {
	final int CAPACITY = 100;
	int length;
	Node front;
	Node tail;
	
	public Queue() {
		super();
		length = 0;
	}
	
	/*
	 * Inserts the specified element into this queue if it is possible 
	 * to do so immediately without violating capacity restrictions, 
	 * returning true upon success and throwing an IllegalStateException 
	 * if no space is currently available.
	 * 
	 */
	 public boolean add (Node node) {
		 if (length == CAPACITY) {
			 try{
		         throw new IllegalStateException();
		       } catch (IllegalStateException e) {
		            e.printStackTrace();
		            return false;
		       }
		 }
		 
		 if (length == 0) {
			 front = node;
		 } else {
			 tail.next = node;
		 }
		 tail = node; // update tail
		 length++;
		 return true;
	 }
	 
	 //Retrieves and removes the front of this queue.
	 public Node remove() {
		 if (length == 0)
			 return null;
		 Node temp = front;
		 front = front.next;
		 length--;
		 return temp;
	 }
	 
	 //Retrieves, but does not remove, the head of this queue, 
	 // or returns null if this queue is empty.
	 public Node peek() {
		 if (length == 0)
			 return null;
		 Node temp = front;
		 return temp;
	 }
	 
	 public void traverse() {
		 if (length == 0) {
			 System.out.println("queue empty");
			 return;
		 }
		 Node cursor = front;
		 System.out.print("queue contents: ");
		 while (cursor != null) {
			 System.out.print(cursor.getElement().getData() + " ");
			 cursor = cursor.next;
		 }
		 System.out.println();
	 }
}
