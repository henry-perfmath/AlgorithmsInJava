package ch9.array;

public class Path {
	int prevNode;
	int distance;
	boolean visited;
	public Path(int prevNode, int distance, boolean visited) {
		super();
		this.distance = distance;
		this.prevNode = prevNode;
		this.visited = visited;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
	public int getPrevNode() {
		return prevNode;
	}
	public void setPrevNode(int prevNode) {
		this.prevNode = prevNode;
	}
	public boolean isVisited() {
		return visited;
	}
	public void setVisited(boolean visited) {
		this.visited = visited;
	}
	
	public String getPathStr () {
		return "prevNode = " + prevNode + " distance = " + distance + " visited = " + visited;
 	}
}
