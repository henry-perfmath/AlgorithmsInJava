package ch9.array;

import java.util.*;

public class DijkstraArray {
	static Path[] path; // relative to origin
	static int maxDistance = 10000;
	static void dijkstra(int[][] cost, int origin) {
		int n = cost.length;
		
		//1. initialize path array
		path = new Path[n];
		for (int i = 0; i < n; i++) {
			path[i] = new Path(origin, cost[origin][i], false);
		}
		
		//2. initialize path for the origin node
		path[0] = new Path(0, 0, true);
		
		//3. find shorted path from the origin for each other node
		int count = 1, minDistance = maxDistance, minNode = 0;
		
		while(count < n) {
			minDistance = maxDistance;
			
			//1. find which unvisited node has shortest distance
			for (int i = 0; i < n; i++) {
				if (!path[i].isVisited() && path[i].getDistance() < minDistance) {
					minDistance = path[i].getDistance();
					minNode = i;
				}
			}
			
			//2. update each unvisited node with shortest path via minNode
			for (int i = 0; i < n; i++) {
				if (!path[i].isVisited() && path[i].getDistance() >
					(minDistance + cost[minNode][i])) {
					path[i].setDistance (minDistance + cost[minNode][i]);
					path[i].setPrevNode (minNode);
				}
			}
			
			//3. mark minNode visited
			path[minNode].setVisited(true);
			count++;
		}
	}
	
	static void test() {
		int n = 9, origin = 0;
		int[][] g = new int[n][n];
		
		for (int i = 0; i< n; i++) {
			for (int j = 0; j < n; j++) {
				g[i][j] = maxDistance;
				//System.out.println("g[" + i + "][" + j + "] = " + g[i][j]);
			}
		}
		
		//Arrays.stream(g).forEach(a -> Arrays.fill(a, maxDistance));
		
		g[0][1] = g[1][0] = 4;
		g[0][7] = g[7][0] = 8;
		g[1][2] = g[2][1] = 8;
		g[1][7] = g[7][1] = 11;
		
		g[2][3] = g[3][2] = 7;
		g[2][8] = g[8][2] = 2;
		g[2][5] = g[5][2] = 4;
		g[3][4] = g[4][3] = 9;
		
		g[3][5] = g[5][3] = 14;
		g[4][5] = g[5][4] = 10;
		g[5][6] = g[6][5] = 2;
		g[6][7] = g[7][6] = 1;
		
		g[6][8] = g[8][6] = 6;
		g[7][8] = g[8][7] = 7;
		
		dijkstra(g, origin);
		
		// print the results
		for (int i = 1; i < n; i++) {
			System.out.print(" Distance of node from origin " + origin 
				+ " to " + i + " is " + path[i].getDistance() 
				 + " : path = " + i);
			
			int j = i;
			do {
				j = path[j].getPrevNode();
				System.out.print (" <- " + j);
			} while (j != origin);
			System.out.println();
		}

	}
	public static void main(String[] args) {
		test();
	}
}
