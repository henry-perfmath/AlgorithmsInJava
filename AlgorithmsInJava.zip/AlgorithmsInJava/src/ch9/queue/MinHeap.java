package ch9.queue;

public class MinHeap {
	int size;
	int capacity;
	int[] pos;
	MinHeapNode[] array;
	public MinHeap(int capacity, int maxDistance) {
		super();
		this.capacity = capacity;
		pos = new int[capacity];
		array = new MinHeapNode[capacity];
		for (int i = 0; i < capacity; i++) {
			this.pos[i] = i;
			this.array[i] = new MinHeapNode(i, maxDistance);
		}
		this.size = capacity;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int[] getPos() {
		return pos;
	}
	public void setPos(int[] pos) {
		this.pos = pos;
	}
	public MinHeapNode[] getArray() {
		return array;
	}
	public void setArray(MinHeapNode[] array) {
		this.array = array;
	}
	
}
