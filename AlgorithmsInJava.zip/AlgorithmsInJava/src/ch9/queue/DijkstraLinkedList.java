package ch9.queue;

import java.util.LinkedList;
import java.util.Queue;

public class DijkstraLinkedList {
	int maxDistance;
	
	public DijkstraLinkedList(int maxDistance) {
		super();
		this.maxDistance = maxDistance;
	}

	void printMinHeap(MinHeap minHeap) {
		int V = minHeap.size;
		for (int v = 0; v < V; v++) {
			int idx = minHeap.array[v].idx;
			int dist = minHeap.array[v].dist;
			System.out.println("minHeap: v = " + v + " vertex = " + idx + " dist = " + dist);
		}
	}
	
	void addEdge(Graph graph, int origin, int dest, int weight) {
		System.out.println("addEdge: origin = " + origin + " dest = " + dest + " weight = " + weight);
		AdjNode destNode = new AdjNode(dest, weight);
		destNode.setNext (graph.getAdjListArray()[origin].getHead());
		graph.getAdjListArray()[origin].setHead(destNode);
		
		AdjNode originNode = new AdjNode(origin, weight);
		originNode.setNext (graph.getAdjListArray()[dest].getHead());
		graph.getAdjListArray()[dest].setHead(originNode);
	}
	public static MinHeapNode swapMinHeapNode(MinHeapNode... args) {
        return args[0];
    }

	void minHeapify(MinHeap minHeap, int idx)
	{
		int smallest, left, right;
		smallest = idx;
		left = 2 * idx + 1;
		right = 2 * idx + 2;

		if (left < minHeap.size && minHeap.array[left].dist < minHeap.array[smallest].dist)
			smallest = left;

		if (right < minHeap.size && minHeap.array[right].dist < minHeap.array[smallest].dist )
			smallest = right;

		if (smallest != idx)
		{
			MinHeapNode smallestNode = minHeap.array[smallest];
			MinHeapNode idxNode = minHeap.array[idx];

			minHeap.pos[smallestNode.idx] = idx;
			minHeap.pos[idxNode.idx] = smallest;

			minHeap.array[idx] = swapMinHeapNode(minHeap.array[smallest], minHeap.array[smallest] = minHeap.array[idx]);

			minHeapify(minHeap, smallest);
		}
	}

	MinHeapNode extractMin(MinHeap minHeap)
	{
		if (minHeap.size == 0)
			return null;

		MinHeapNode root = minHeap.array[0];
		MinHeapNode lastNode = minHeap.array[minHeap.size - 1];
		minHeap.array[0] = lastNode;

		minHeap.pos[root.idx] = minHeap.size-1;
		minHeap.pos[lastNode.idx] = 0;

		--minHeap.size;
		minHeapify(minHeap, 0);

		return root;
	}

	void decreaseKey(MinHeap minHeap, int idx, int dist)
	{
		int i = minHeap.pos[idx];

		minHeap.array[i].dist = dist;

		int parentIndex = (i - 1) / 2;
		while (i > 0 && minHeap.array[i].dist < minHeap.array[parentIndex].dist)
		{
			minHeap.pos[minHeap.array[i].idx] = parentIndex;
			minHeap.pos[minHeap.array[parentIndex].idx] = i;
			minHeap.array[i] = swapMinHeapNode(minHeap.array[parentIndex], minHeap.array[parentIndex] = minHeap.array[i]);
			i = parentIndex;
			parentIndex = (i - 1) / 2;
		}
	}

	void printDistArray(int dist[], int n)
	{
		System.out.println("\nprintDistArray to verify vertex distance from source 0 ...");
		for (int i = 0; i < n; ++i)
			System.out.println(i + "\t\t " + dist[i]);
	}

	void dijkstra(Graph graph, int origin)
	{
		int V = graph.V;
		int[] dist = new int[V];

		for (int i = 0; i < V; i++) {
			dist[i] = maxDistance;
		}

		dist[origin] = 0;
		
		MinHeap minHeap = new MinHeap(V, maxDistance);
		
		System.out.println("\nmeanHeap idx:");
		while (minHeap.size > 0)
		{
			int originIdx = extractMin(minHeap).getIdx();
			System.out.print(originIdx + " ");
			AdjNode adjListHead = graph.adjListArray[originIdx].head;

			while (adjListHead != null)
			{
				int weight = adjListHead.weight;
				int dest = adjListHead.dest;
				if ((dist[originIdx] + weight) < dist[dest])
				{
					dist[dest] = dist[originIdx] + weight;
					decreaseKey(minHeap, dest, dist[dest]);
				}
				adjListHead = adjListHead.next;
			}
		}
		System.out.println();
		printDistArray(dist, V);
	}

	void printAdjListArray(Graph graph) {
		int n = graph.V;
		System.out.println("\nprintAdjListArray to verify grpah building ...\ngraph size = " + n);
		for (int i = 0; i < n; i++) {
			AdjNode node  = graph.adjListArray[i].head; // use . not ->
			System.out.print("adjacent nodes for i = " + i + ":  \n");
			int count = 0;
			while (node != null) {
				if (count > 0) System.out.print("| ");
				System.out.print("node " + node.dest +"(" + node.weight + ")");
				node = node.next;
				count++;
			}
			System.out.println();
		}
	}

	void bft(Graph graph) {
		int n = graph.V;
		boolean[] visited = new boolean[n];
		boolean[] enqueued = new boolean[n]; // need 2 state arrays
		for (int i = 0; i < n; i++) {
			visited[i] = false;
			enqueued[i] = false;
		}
		System.out.println("\nbft traversing with graph size = " + n);
		//Queue<Integer> queue = new LinkedList<Integer>();
		LinkedList<Integer> queue = new LinkedList<Integer>();
		int origin = 0;
		Integer item = new Integer(origin);
		queue.add(item);

		while (queue.size() > 0) {
			Integer head = queue.remove();
			origin = Integer.valueOf(head);
			if(!visited[origin]) {
				System.out.print(origin + " ");
				visited[origin] = true;
			}

			AdjNode node  = graph.adjListArray[origin].head;
			while (node != null) {
				int dest = node.dest;
				if(!visited[dest] && !enqueued[dest]) {
					queue.add(new Integer(dest));
					enqueued[Integer.valueOf(dest)] = true;
				}
				node = node.next;
			}
		}
		//System.out.println();
	}
}
