package ch9.queue;

public class Graph {
	int V; // # of vertices
	AdjList[] adjListArray;
	public Graph(int v) {
		super();
		V = v;
		adjListArray = new AdjList[v];

		for (int i = 0; i < V; ++i)
			adjListArray[i] = new AdjList();
	}
	public int getV() {
		return V;
	}
	public void setV(int v) {
		V = v;
	}
	public AdjList[] getAdjListArray() {
		return adjListArray;
	}
	public void setAdjListArray(AdjList[] adjListArray) {
		this.adjListArray = adjListArray;
	}
	
}
