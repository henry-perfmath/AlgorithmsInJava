package ch9.queue;

public class DijkstraLinkedListTest {
	static int maxDistance = 10000;
	
	public static void main(String[] args) {
		int V = 9;
		//int V = 6;
		DijkstraLinkedList dijkstraQueue = new DijkstraLinkedList(maxDistance);
		Graph graph = new Graph(V); // origin, dest, weight

		System.out.println("build graph ...");
		dijkstraQueue.addEdge(graph, 0, 1, 4);
		dijkstraQueue.addEdge(graph, 0, 7, 8);
		dijkstraQueue.addEdge(graph, 1, 2, 8);
		dijkstraQueue.addEdge(graph, 1, 7, 11);
		dijkstraQueue.addEdge(graph, 2, 3, 7);
		dijkstraQueue.addEdge(graph, 2, 8, 2);
		dijkstraQueue.addEdge(graph, 2, 5, 4);
		dijkstraQueue.addEdge(graph, 3, 4, 9);
		dijkstraQueue.addEdge(graph, 3, 5, 14);
		dijkstraQueue.addEdge(graph, 4, 5, 10);
		dijkstraQueue.addEdge(graph, 5, 6, 2);
		dijkstraQueue.addEdge(graph, 6, 7, 1);
		dijkstraQueue.addEdge(graph, 6, 8, 6);
		dijkstraQueue.addEdge(graph, 7, 8, 7);
		/*
		dijkstraQueue.addEdge(graph, 0, 1, 5);
		dijkstraQueue.addEdge(graph, 0, 2, 3);
		dijkstraQueue.addEdge(graph, 0, 3, 2);
		dijkstraQueue.addEdge(graph, 0, 4, 3);
		dijkstraQueue.addEdge(graph, 0, 5, 3);
		dijkstraQueue.addEdge(graph, 2, 1, 2);
		dijkstraQueue.addEdge(graph, 2, 3, 3);
		 */
		//1. verify graph is built correctly
		dijkstraQueue.printAdjListArray(graph);

		// 2. solve the problem
		dijkstraQueue.dijkstra(graph, 0);

		// 3. verify the solution
		dijkstraQueue.bft(graph);
		
	}
}
