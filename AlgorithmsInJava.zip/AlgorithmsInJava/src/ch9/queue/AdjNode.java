package ch9.queue;

public class AdjNode {
	int dest;
	int weight;
	AdjNode next;
	public AdjNode(int dest, int weight) {
		super();
		this.dest = dest;
		this.weight = weight;
		this.next = null;
	}
	public int getDest() {
		return dest;
	}
	public void setDest(int dest) {
		this.dest = dest;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public AdjNode getNext() {
		return next;
	}
	public void setNext(AdjNode next) {
		this.next = next;
	}
	
}
