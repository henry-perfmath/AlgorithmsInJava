package ch9.queue;

public class MinHeapNode {
	int idx;
	int dist;
	public MinHeapNode(int idx, int dist) {
		super();
		this.idx = idx;
		this.dist = dist;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getDist() {
		return dist;
	}
	public void setDist(int dist) {
		this.dist = dist;
	}
	
}
