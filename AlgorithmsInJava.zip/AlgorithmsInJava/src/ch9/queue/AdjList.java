package ch9.queue;

public class AdjList {
	AdjNode head;

	public AdjList() {
		super();
		this.head = null;
	}

	public AdjNode getHead() {
		return head;
	}

	public void setHead(AdjNode head) {
		this.head = head;
	}
	
}
