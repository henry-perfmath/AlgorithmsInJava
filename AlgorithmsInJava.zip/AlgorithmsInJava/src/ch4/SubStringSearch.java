package ch4;

public class SubStringSearch {
	public static int getIndex(char[] mainStr, char[] subStr) {
		int i = 0, j = 0;
		while (i < mainStr.length) {
			System.out.println ("0 i = " + i + " " + mainStr[i] + " j = " + j + " " + subStr[j]);
			while (mainStr[i] == subStr[j]) {
				System.out.println ("1 i = " + i + " " + mainStr[i] + " j = " + j + " " + subStr[j]);
				i++;
				j++;
			}

			if (j == subStr.length - 1) {
				return i;
			} else {
				i++;
				j = 0;
			}
		}
		return -1;
	}
	
	public static void main(String[] args) {
		char[] mainStr = "This is a test".toCharArray();
		char[] subStr = "is a".toCharArray();
		printCharArray(mainStr);
		printCharArray(subStr);
		
		int index = getIndex(mainStr, subStr);

		if (index > 0) {
			int n = mainStr.length - index;
			char[] substring = new char[n];
			for (int i = 0; i < n; i++) {
				substring[i] = mainStr[i + index];
			}
			for (int i = 0; i < n; i++) {
				System.out.print(substring[i]);
			}
		} else {
			System.out.println("no substring found");
		}
	}
	
	public static void printCharArray(char[] charArr) {
		for (int i = 0; i < charArr.length; i++) {
			System.out.print(charArr[i]);
		}
		System.out.print("\n");
	}
}
