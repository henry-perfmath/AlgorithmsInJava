package ch4;

public class SubStringSearch2 {
	public static String getSubstring(String mainStr, String subString) {
		int index = mainStr.indexOf(subString);
		if (index > 0) {
			return mainStr.substring(index);
		} else {
			return "";
		}
	}
	
	public static void main(String[] args) {
		String mainStr = "This is a test";
		String subStr = "is a";
		System.out.println(getSubstring(mainStr, subStr));
	}
}
