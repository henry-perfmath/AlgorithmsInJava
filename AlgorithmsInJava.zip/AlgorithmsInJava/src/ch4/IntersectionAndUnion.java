package ch4;

import java.util.ArrayList;
import java.util.HashSet;

public class IntersectionAndUnion {
	
	public static ArrayList<Integer> getIntersection(int[]a, int[] b) {
		int m = a.length;
		int n = b.length;
		ArrayList<Integer> intersection = new ArrayList<Integer>();
		int i = 0, j = 0;
		
		while (i < m && j < n) {
			if (a[i] < b[j]) {
				i++;
			} else if (b[j] < a[i]) {
				j++;
			} else {
				intersection.add(a[i]);
				i++;
				j++;
			}
		}
		return intersection;
	}
	
	public static ArrayList<Integer> getUnion(int[]a, int[] b) {
		int m = a.length;
		int n = b.length;
		ArrayList<Integer> union = new ArrayList<Integer>();
		int i = 0, j = 0;
		
		while (i < m && j < n) {
			if (a[i] < b[j]) {
				union.add(a[i]);
				i++;
			} else if (b[j] < a[i]) {
				union.add(b[j]);
				j++;
			} else {
				union.add(a[i]);
				i++;
				j++;
			}
		}
		return union;
	}

	public static void main(String[] args) {
		int[] a = {1, 3, 5, 7, 9, 11, 12, 13, 14, 15, 16};
		int[] b = {2, 3, 6, 8, 9, 10, 13, 16};
		
		System.out.print("a: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
		
		System.out.print("\nb: ");
		for (int i = 0; i < b.length; i++) {
			System.out.print(b[i] + " ");
		}
		
		ArrayList<Integer> c = getIntersection(a, b);
		System.out.print("\nIntersection: ");
		for (int i = 0; i < c.size(); i++) {
			System.out.print(c.get(i) + " ");
		}
		
		System.out.print("\nUnion: ");
		ArrayList<Integer> d = getUnion(a, b);
		for (int i = 0; i < d.size(); i++) {
			System.out.print(d.get(i) + " ");
		}
	}
}
