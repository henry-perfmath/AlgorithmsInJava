package ch4;

import java.util.Arrays;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MaxSubSeqSum {
	
	public static int maxSubSeqSum(int[] a) {
		int maxSum = 0, sum = 0;
		String subSeq = "";
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
			if (sum > maxSum) {
				maxSum = sum;
			} else if (sum < 0) {
				sum = 0;
				subSeq = "";
			} 
			if (sum > 0) {
				subSeq += a[i] + " ";
			}
			System.out.println("subSeq = " + subSeq + " sum = " + sum);
		}
		return maxSum;
	}

	public static void main(String[] args) {
		int[] a = {7, 9, -1, -2, 2, -16, 7, 8, 10, -9, -3, -2, -18, 3, 1, 6, -5, 10, 10};
		//System.out.println("input: " + IntStream.of(a).boxed().collect(Collectors.toList()));
		System.out.println("input: " + Arrays.toString(a));
		int maxSum = maxSubSeqSum(a);
		System.out.println("maxSum = " + maxSum);
	}
}
