package ch4;

import java.util.Arrays;
import java.util.HashSet;

public class IntersectionAndUnionUnsorted {
	
	public static HashSet<Integer> getIntersection(int[]a, int[] b) {
		int m = a.length;
		int n = b.length;
		Integer[] A = new Integer[m];
		for (int i = 0; i <m; i++) {
			A[i] = Integer.valueOf(a[i]);
		}
		
		Integer[] B = new Integer[n];
		for (int i = 0; i <n; i++) {
			B[i] = Integer.valueOf(b[i]);
		}
		
		HashSet<Integer> setA = new HashSet<Integer>();
		setA.addAll(Arrays.asList(A));
		HashSet<Integer> setB = new HashSet<Integer>();	
		setB.addAll(Arrays.asList(B));

		System.out.println("\nsetA: " + setA);
		System.out.println("setB: " + setB);
		
		HashSet<Integer> intersection = new HashSet<Integer>();
		for (int i = 0; i < m; i++) {
			if (setA.contains(A[i]) && setB.contains(A[i])) {
				intersection.add(A[i]);
			}
		}

		return intersection;
	}
	
	public static HashSet<Integer> getUnion(int[]a, int[] b) {
		int m = a.length;
		int n = b.length;
		Integer[] A = new Integer[m];
		for (int i = 0; i <m; i++) {
			A[i] = Integer.valueOf(a[i]);
		}
		
		Integer[] B = new Integer[n];
		for (int i = 0; i <n; i++) {
			B[i] = Integer.valueOf(b[i]);
		}
		
		HashSet<Integer> setA = new HashSet<Integer>();
		setA.addAll(Arrays.asList(A));
		HashSet<Integer> setB = new HashSet<Integer>();	
		setB.addAll(Arrays.asList(B));

		System.out.println("\nsetA: " + setA);
		System.out.println("setB: " + setB);
		
		HashSet<Integer> union = new HashSet<Integer>();
		union.addAll(setA);
		union.addAll(setB);

		return union;
	}

	public static void main(String[] args) {
		//int[] a = {1, 13, 5, 17, 9, 11, 12, 3, 24, 15, 16};
		//int[] b = {2, 13, 16, 28, 24, 15, 13, 16};
		int[] a = {1, 3, 5, 7, 9, 11, 12, 13, 14, 15, 16};
		int[] b = {2, 3, 6, 8, 9, 10, 13, 16};
		
		System.out.print("a: ");
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
		}
		
		System.out.print("\nb: ");
		for (int i = 0; i < b.length; i++) {
			System.out.print(b[i] + " ");
		}
		
		HashSet<Integer> c = getIntersection(a, b);
		System.out.println("Intersection: " + c);
		
		HashSet<Integer> d = getUnion(a, b);
		System.out.println("Union: " + d);
	}
}
