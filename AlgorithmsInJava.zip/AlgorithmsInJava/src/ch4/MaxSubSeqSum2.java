package ch4;

import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class MaxSubSeqSum2 {

	public static int maxSubSeqSum(int[] a) {
		int maxSum = 0, sum = 0, j = 0, k = 0;
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
			if (sum > maxSum) {
				maxSum = sum;
				k = i;
			} else if (sum < 0) {
				sum = 0;
				j = i;
				k = i;
			} 
		}
		return maxSum;
	}
	
	public static int maxSubSeqSum2(int[] a) {
		int maxSum = 0, sum = 0;
		for (int i = 0; i < a.length; i++) {
			sum += a[i];
			if (sum > maxSum) {
				maxSum = sum;
			} else if (sum < 0) {
				sum = 0;
			}
		}
		return maxSum;
	}

	public static void main(String[] args) {
		
		Random rndm = new Random();
		int max = 100;
		int min = -max;
		int n = 40000000;
		int[] a = new int[n];
		
		for(int i =0; i < n; i++)
		{
		    int rndmInt = rndm.nextInt((max - min) + 1) + min;
		    a[i] = rndmInt;
		}

		long startTime = System.currentTimeMillis();
		int maxSum = maxSubSeqSum(a);
		System.out.println("maxSum = " + maxSum + " taken " + (System.currentTimeMillis() - startTime) + " ms");
	}
}
