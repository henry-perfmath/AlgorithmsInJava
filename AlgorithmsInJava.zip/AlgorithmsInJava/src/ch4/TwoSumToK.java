package ch4;

import java.util.Arrays;

public class TwoSumToK {
	public static int[] linearSearch(int[] a, int k) {
		int start = 0, end = a.length - 1;
		int[] indices = {-1, -1};
		while (start < end) {
			int sum = a[start] + a[end];
			if (sum < k) {
				start++;
			} else if (sum > k) {
				end--;
			} else {
				indices[0] = start;
				indices[1] = end;
				break;
			}
		}
		return indices;
	}
	
	public static void main(String[] args) {
		int[] a = {0, 29, 24, 16, 3, 3, 3, 29, 27, 16};
		System.out.println("input: " + Arrays.toString(a));
		int k = 51;
		Arrays.sort(a);
		System.out.println("sorted: " + Arrays.toString(a));
		int[] indices = linearSearch(a, k);
		if (indices[0] > -1 && indices[1] > -1) {
			System.out.println("found: " + a[indices[0]] + " + " + a[indices[1]] + " = " + k);
		} else {
			System.out.println("not found");
		}
	}
}
