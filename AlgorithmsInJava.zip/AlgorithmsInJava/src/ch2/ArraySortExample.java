package ch2;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.IntStream;

public class ArraySortExample {
	public static void main(String[] args) {
		int[][] a = { {9, 7, 5, 3, 1},  
					{6, 4, 2},  
					{0}};

		for (int[] row : a) {
			int length = row.length;
			System.out.print("\n1. by row using index: ");
			for (int j = 0; j < length; j++) {
				System.out.print(row[j] + " ");
			}
			
			System.out.print("\n2. by row without using index in ascending order: ");	
			Arrays.sort(row);
			for (int x : row) {
				System.out.print(x + " ");
			}
			
			System.out.print("\n3. by row without using index in descending order: ");	
			Integer[] rowInt = IntStream.of(row).boxed().toArray( Integer[]::new );
			Arrays.sort(rowInt, Collections.reverseOrder());
			for (int x : rowInt) {
				System.out.print(x + " ");
			}
			System.out.println();
		}
	}
}
