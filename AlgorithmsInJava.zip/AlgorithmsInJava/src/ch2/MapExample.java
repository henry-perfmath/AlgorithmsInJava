package ch2;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.Random;
import java.util.TreeMap;

public class MapExample {
	public static void main(String[] args) {

		Map<Double, String> map = new HashMap<Double, String>();
		LinkedHashMap<Double, String> linkedMap = new LinkedHashMap<Double, String>();
		char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
		
		double[] x = new double [10];
		
		Random random = new Random();
		double max = 100.0;
		for (int i = 0; i < x.length; i++) {
			x[i] = random.nextDouble() * max;
			map.put(x[i], String.valueOf(alphabet[i]));
			linkedMap.put(x[i], String.valueOf(alphabet[i]));
		}
		
		System.out.println("1. unsorted map:");
		for (double key : map.keySet()) {
			System.out.println(key + " -> " + map.get(key));
		}
		
		System.out.println("\n2. linked map:");
		for (double key : linkedMap.keySet()) {
			System.out.println(key + " -> " + linkedMap.get(key));
		}
		
		TreeMap<Double, String> treeMap = new TreeMap<Double, String>(map);
		System.out.println("\n3. sorted map in ascending order:");
		for (double key : treeMap.keySet()) {
			System.out.println(key + " -> " + treeMap.get(key));
		}

		System.out.println("\n4. sorted map in descending order:");
		NavigableMap<Double, String> sortedMap = treeMap.descendingMap();
		for (double key : sortedMap.keySet()) {
			System.out.println(key + " -> " + sortedMap.get(key));
		}
	}
}
