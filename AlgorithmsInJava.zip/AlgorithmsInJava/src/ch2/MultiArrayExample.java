package ch2;

public class MultiArrayExample {
	public static void main(String[] args) {
		int[][] a = { {9, 7, 5, 3, 1},  
					{6, 4, 2},  
					{0}};

		for (int[] row : a) {
			int length = row.length;
			System.out.print("\nby row using index: ");
			for (int j = 0; j < length; j++) {
				System.out.print(row[j] + " ");
			}
			
			System.out.print("\nby row without using index: ");			
			for (int x : row) {
				System.out.print(x + " ");
			}
			System.out.println();
		}
	}
}
