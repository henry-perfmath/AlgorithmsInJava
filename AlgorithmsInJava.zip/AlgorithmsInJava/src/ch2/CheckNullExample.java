package ch2;

public class CheckNullExample {
	public static void main(String[] args) throws Exception {

		String[] strArray = new String[5];
		strArray[3] = "3";
		for (int i = 0; i < strArray.length; i++) {
			//if (strArray[i] == null) strArray[i] = "";
			//System.out.print(strArray[i] + " ");
			System.out.print(getStr(strArray[i]) + " ");			
		}
		System.out.print("\nprogram completed");
	}

	public static String getStr(String str) {
		if (str == null) {
			str = "";
		}
		return str;
	}
}
