package ch2;

import java.util.Arrays;
import java.util.List;

public class StringSplitExample {
	public static void main(String[] args) {
		String inputStr = "apple, organge, tomato";
		System.out.println("0. input string: " + inputStr);
		System.out.print("\n1. split into a List<String> object: ");
		
		List<String> items = Arrays.asList(inputStr.split(","));
		for (int i = 0; i < items.size(); i++) {
			System.out.print(items.get(i) + ">");
		}
		
		System.out.print("\n2. split into a String array: ");
		String[] strArray = inputStr.split(",");
		for (int i = 0; i < strArray.length; i++) {
			System.out.print(strArray[i] + ">");
		}
	}
}
