package ch2;

public class JavaSwap {
	static int swap (int... args) {
		return args[0];
	}
	
	public static void main (String[] args) {
		int a  = 5;
		int b = 10;
		
		System.out.println("before swap: a = " + a + ", b = " + b);
		a = swap(b, b = a);
		System.out.println("after swap: a = " + a + ", b = " + b);
	}
}
