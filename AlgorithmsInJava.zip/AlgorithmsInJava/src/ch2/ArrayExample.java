package ch2;

public class ArrayExample {
	public static void main(String[] args) {
		// 1. array initialization
		int[] c = {1, 3, 5, 7, 9};
		//int[] c = new int[] {1, 3, 5, 7, 9};
		
		System.out.print("\n1. array initialization: ");
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i] + " ");
		}

		// 2. array returned from another method
		System.out.print("\n2. array returned from another method: ");
		int[] x = getInts();
		for (int i = 0; i < x.length; i++) {
			System.out.print(x[i] + " ");
		}

		//3. default values for a primitive type of array
		System.out.print("\n3. default values for a primitive type of array: ");
		int[] z = new int[5];
		for (int i = 0; i < z.length; i++) {
			System.out.print(z[i] + " ");
		}

		//4. default values for a String type of array
		System.out.print("\n4. default values for a String type of array: ");
		String[] strArray = new String[5];
		for (int i = 0; i < strArray.length; i++) {
			System.out.print(strArray[i] + " ");
		}
		
		//5. default values for a String type of array
		System.out.print("\n5. check null for an uninitialized String type of array: ");
		boolean[] strNull = new boolean[strArray.length];
		for (int i = 0; i < strArray.length; i++) {
			if (strArray[i] == null) strNull[i] = true;
			System.out.print(strNull[i] + " ");
		}
		
		//6. default values for a String type of array
		System.out.println("\n6. check null value for an uninitialized String type of array: ");
		for (int i = 0; i < strArray.length; i++) {
			if (strArray[i].equals("null")) strArray[i] = "";
			System.out.print(strArray[i] + " ");
		}
	}
	
	public static int[] getInts() {
		int a = 1;
		int b = 3;
		int c = 5;
		return new int[] {a, b, c};
	}
}
