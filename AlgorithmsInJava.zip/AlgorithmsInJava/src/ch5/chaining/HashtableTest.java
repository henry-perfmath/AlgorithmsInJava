package ch5.chaining;

public class HashtableTest {
	public static void main(String[] args) {
		int cycle;
		int maxCycles = 10;
		int testKey = 3;
		int testValue;
		
		int cacheSize = 8;
		cycle = 1;
		Hashtable<Integer, Integer> table = new Hashtable<>();

		// use cycle to generate overlapping items
		while (cycle < maxCycles) {
			for (int i = 0; i < cacheSize; i++) {
				int key = i * cycle;
				int value = 100 * i * cycle;
				table.put(i * cycle, 100 * i * cycle);
				System.out.print(cycle + "/" + i + ":(" + key + "," + value + ")/" + table.size() + " ");
			}
			System.out.println();
			cycle++;
		}
		table.traverse();

		// test get
		if (table.get(testKey) != null) {
			testValue = table.get(testKey);
			System.out.println("key = " + testKey + " value = " + testValue);
		} else {
			System.out.println("key = " + testKey + " does not exist ");
		}

		// test delete
		if (table.delete(testKey) != null ) {
			System.out.println("delete key = " + testKey + " successful");
		} else {
			System.out.println("delete key = " + testKey + " not found");
		}
		table.traverse();

		// test get deleted item
		if (table.get(testKey) != null) {
			testValue = table.get(testKey);
			System.out.println("key = " + testKey + " value = " + testValue);
		} else {
			System.out.println("key = " + testKey + " does not exist ");
		}

		// test clear
		table.clear();

		System.out.println("table size = " + table.size());
	}
}
