package ch5.chaining;

import java.util.Objects;

// a node has a key-value pair, a hashcode and next node 
public class Node<K, V> {
	K key;
	V value;
	final int hashCode;
	Node<K, V> next;

	public Node(K key, V value) {
		this.key = key;
		this.value = value;
		this.hashCode = Math.abs(Objects.hashCode(key));
	}
}
