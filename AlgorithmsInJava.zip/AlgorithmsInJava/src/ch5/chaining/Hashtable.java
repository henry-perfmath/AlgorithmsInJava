package ch5.chaining;

import java.util.ArrayList;
import java.util.Objects;

public class Hashtable<K, V> {

	private ArrayList<Node<K, V>> table;
	private int CAPACITY;
	private int size; // usage of capacity

	public Hashtable() {
		CAPACITY = 21; //total capacity
		size = 0; // used capacity
		table = new ArrayList<>();
		for (int i = 0; i < CAPACITY; i++)
			table.add(null);
	}

	public int size() {
		return size;
	}

	public boolean isEmpty() {
		return size() == 0;
	}

	private final int getHashCode(K key) {
		int hashCode = Math.abs(Objects.hashCode(key)); // avoid negative hashcode
		return hashCode;
	}

	private int getIndex(K key) {
		int hashCode = getHashCode(key);
		int index = hashCode % CAPACITY;
		return index;
	}

	public V get(K key) {
		int index = getIndex(key);
		Node<K, V> head = table.get(index);

		int hashCode = getHashCode(key);	
		while (head != null) {
			if (head.key.equals(key) && head.hashCode == hashCode)
				return head.value;
			head = head.next;
		}

		return null; // key not found
	}

	public void put(K key, V value) {
		// 0. get hashCode, index(bucket) and head
		int hashCode = getHashCode(key);
		int index = getIndex(key);
		Node<K, V> cursor = table.get(index);

		// 1. updated Value if existing
		while (cursor != null) {
			if (cursor.key.equals(key) && cursor.hashCode == hashCode) {
				cursor.value = value;
				return; 
			}
			cursor = cursor.next;
		}

		// 2. add new node as head
		Node<K, V> node = new Node<K, V>(key, value);
		node.next = table.get(index);
		table.set(index, node); // replace
		size++;
		
		// 3. if  utilization above threshold, double the capacity
		if ((1.0 * size) / CAPACITY >= 0.7) {
			System.out.println("\n\ncalling resizing ...\n");
			resize();
		}
	}
	
	public void resize() {
		ArrayList<Node<K, V>> temp = table;
		table = new ArrayList<>();
		CAPACITY = 2 * CAPACITY;
		size = 0;
		for (int i = 0; i < CAPACITY; i++)
			table.add(null);

		for (Node<K, V> head : temp) {
			while (head != null) {
				put(head.key, head.value);
				head = head.next;
			}
		}
	}
	
	public V delete(K key) {
		//0. get hashCode, index(bucket) and head
		int hashCode = getHashCode(key);
		int index = getIndex(key);
		Node<K, V> head = table.get(index);
		
		//1. does not exist
		if (head == null)
			return null;
		
		//2. delete head node
		if (head.key.equals(key) && hashCode == head.hashCode) {
			V value = head.value;
			head = head.next;
			if (head == null) size--;
			return value;
		}
		
		//3. delete in the chain
		Node<K, V> prev = head;
		Node<K, V>  curr = prev.next;
		while (curr != null && !curr.key.equals(key)) {
			curr = curr.next;
			prev = curr;
		}
	    if (curr != null) { // found
	    	V value = curr.value;
			prev.next = curr.next; // delete curr
		    return value;
		}
		return null;
	}

	public V delete0(K key) {
		int hashCode = getHashCode(key);
		int index = getIndex(key);
		Node<K, V> head = table.get(index);

		Node<K, V> prev = null;
		while (head != null) {
			if (head.key.equals(key) && hashCode == head.hashCode)
				break;

			prev = head;
			head = head.next;
		}

		if (head == null)
			return null; // not found

		size--; 
		if (prev != null)
			prev.next = head.next;
		else
			table.set(index, head.next);

		return head.value;
	}
	
	public void clear() {
		System.out.println("clear:");
		for (int i = 0; i < CAPACITY; i++) {
			Node<K, V> head = table.get(i); // head
			while (head != null) {
				head = head.next;
			}
		}
		size = 0;
	}

	public void traverse() {
		System.out.println("traverse:");
		for (int i = 0; i < CAPACITY; i++) {
			Node<K, V> head = table.get(i);
			System.out.print(i + ": ");
			while (head != null) {
				System.out.print("(" + head.key + "," + head.value + ")");
				head = head.next;
			}
		}
		System.out.println("\nsize = " + size);
  }
}
