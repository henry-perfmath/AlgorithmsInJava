package ch5.hws;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class HashtableTest {

    public static void main(String[] args){
     Scanner in = new Scanner (System.in); 
       HashTable table = new HashTable(2);
       String key,value;
       while (true) {
          System.out.println("\nMenu:");
          System.out.println("   1. test put(key,value)");
          System.out.println("   2. test get(key)");
          System.out.println("   3. test containsKey(key)");
          System.out.println("   4. test remove(key)");
          System.out.println("   5. show complete contents of hash table.");
          System.out.println("   6. EXIT");
          System.out.print("Enter your command:  ");
          switch ( Integer.parseInt(in.nextLine())) {
             case 1:
                System.out.print("\n   Key = ");
                key = in.nextLine();
                System.out.print("   Value = ");
                value = in.nextLine();
                table.put(key,value);
                break;         
             case 2:
                System.out.print("\n   Key = ");
                key = in.nextLine();
                System.out.println("   Value is " + table.get(key));
                break;         
             case 3:
                System.out.print("\n   Key = ");
                key = in.nextLine();
                System.out.println("   containsKey(" + key + ") is " 
                                             + table.containsKey(key));
                break;         
             case 4:
                System.out.print("\n   Key = ");
                key = in.nextLine();
                table.remove(key);
                break;         
             case 5:
                table.dump();
                break;
             case 6:
            	in.close();
                return;  // End program by returning from main()         
             default:
                System.out.println("   Illegal command.");
                break;
          }
          System.out.println("\nHash table size is " + table.size());
       }
       
    }

 }