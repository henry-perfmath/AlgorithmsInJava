package ch5.simple;

import ch5.probing.Entry;
//based on https://www.algolist.net/Data_structures/Hash_table/Simple_example
public class SimpleHashtable {
	private final static int CAPACITY = 101;
	 
    Entry[] table;

    SimpleHashtable() {
          table = new Entry[CAPACITY];
          init();
    }

    public void init() {
    	for (int i = 0; i < CAPACITY; i++)
            table[i] = null;
    }
    public int get(int key) {
          int hash = (key % CAPACITY);
          while (table[hash] != null && table[hash].getKey() != key)
                hash = (hash + 1) % CAPACITY;
          if (table[hash] == null)
                return -1;
          else
                return table[hash].getValue();
    }

    public void put(int key, int value) {
          int hash = (key % CAPACITY);
          while (table[hash] != null && table[hash].getKey() != key)
                hash = (hash + 1) % CAPACITY;
          table[hash] = new Entry(key, value);
    }
    // added
    public void delete(int key) {
        int hash = (key % CAPACITY);
        while (table[hash] != null && table[hash].getKey() != key)
              hash = (hash + 1) % CAPACITY;
        table[hash] = null;
  }
    // added
    public void clear() {
        init();
  }
}
