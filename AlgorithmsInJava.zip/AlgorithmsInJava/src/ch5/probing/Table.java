package ch5.probing;
// linear probing of open addressing strategy
public class Table {
	private final static int CAPACITY = 101;
	 
    Entry[] table;

    Table() {
          table = new Entry[CAPACITY];
          for (int i = 0; i < CAPACITY; i++)
                table[i] = null;
    }

    public int get(int key) {
          int hash = (key % CAPACITY);
          Entry entry = table[hash];
          while (entry != null) {
        	  if (entry.getKey() == key)
        		  return entry.getValue();
        	  hash = (hash + 1) % CAPACITY;
        	  entry = table[hash];
          }
          return -1;
    }

    public void put(int key, int value) {
          int hash = (key % CAPACITY);
          Entry entry = table[hash];
          
          // 1. update
          while (entry != null) {
        	  if (entry.getKey() == key) { 
        		  table[hash] = new Entry(key, value);
        		  return;
        	  }
        	  hash = (hash + 1) % CAPACITY;
        	  entry = table[hash];
          }
          
          //2. does not exist. add new
          if (entry == null) {
        	  table[hash] = new Entry(key, value);
          }

          //3a. exist. put at the end
    	  hash = (hash + 1) % CAPACITY;
    	  table[hash] = entry;
          
          //3b. put at the head
    	  /*
    	  while (hash > 0) {
    		  table[hash] = table[hash--];
    	  }
    	  table[0] = entry;
    	  */
    }
    
    public int delete(int key) {
        int hash = (key % CAPACITY);
        Entry entry = table[hash];
        if (entry == null) 
        	return 0; // does not exist
        else {
        	while (entry != null) {
          	  if (entry.getKey() == key) { 
          		  table[hash] = null;
          		  return 1;
          	  }
          	  hash = (hash + 1) % CAPACITY;
          	  entry = table[hash];
            }
        	return 0;
        }
  }
    
    public void clear() {
    	for (int i = 0; i < CAPACITY; i++) {
    		table[i] = null;
    	}
  }
}
