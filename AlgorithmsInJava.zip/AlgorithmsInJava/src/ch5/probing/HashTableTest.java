package ch5.probing;

public class HashTableTest {
	public static void main(String[] args) {
		int cycle;
		int maxCycles = 10;
		int testKey = 3;
		int testValue;
		
		int cacheSize = 10;
		cycle = 1;
		Table table = new Table();
		
		while (cycle < maxCycles) {
			for (int i = 0; i < cacheSize; i++) {
				int key = i * cycle;
				int value = 100 * i * cycle;
				table.put(i * cycle, 100 * i * cycle);
				System.out.print("(" + key + "," + value + ") ");
			}
			System.out.println();
			cycle++;
		}
		
		// test get
		testValue = table.get(testKey);
		System.out.println("key = " + testKey + " value = " + testValue);
		
		// test delete
		if (table.delete(testKey) > 0) {
			System.out.println("delete key = " + testKey + " successful");
		} else {
			System.out.println("delete key = " + testKey + " not found");
		}
		
		// test get the same testKey
		testValue = table.get(testKey);
		System.out.println("key = " + testKey + " value = " + testValue);
		
		// test delete the same testKey
		if (table.delete(testKey) > 0) {
			System.out.println("delete key = " + testKey + " successful");
		} else {
			System.out.println("delete key = " + testKey + " not found");
		}
		
		// test clear
		table.clear();
	}
}
