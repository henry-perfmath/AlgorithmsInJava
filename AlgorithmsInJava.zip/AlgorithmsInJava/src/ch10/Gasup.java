package ch10;

import java.util.*;
public class Gasup {
	 private class City {
		char symbol;
		int gas;
		int miles;
		double remainingGas;
		public City(char symbol, int gas, int miles, double remainingGas) {
			super();
			this.symbol = symbol;
			this.gas = gas;
			this.miles = miles;
			this.remainingGas = remainingGas;
		}
	}

	double findCity(City[] cities, int n, int startIdx) {
		int count = 0;
		double currGas = 0;
		int idx = startIdx;
		while (count < n) {
			idx = (count + startIdx) % n;
			currGas = currGas + cities[idx].remainingGas;
			if (currGas < 0) return currGas;
			count++;
		}
		return currGas;
	}

	void test1() {
		int numCities = 7;
		City[] cities = new City[numCities];
		City cityA = this.new City('A', 50, 900, 0.0);
		cities[0] = cityA;
		City cityB = this.new City('B', 20, 600, 0.0);
		cities[1] = cityB;
		City cityC = this.new City('C', 5, 200, 0.0);
		cities[2] = cityC;

		City cityD = this.new City('D', 30, 400, 0.0);
		cities[3] = cityD;

		City cityE = this.new City('E',25, 600, 0.0);
		cities[4] = cityE;

		City cityF = this.new City('F', 10, 200, 0.0);
		cities[5] = cityF;
		City cityG = this.new City('G', 10, 100, 0.0);
		cities[6] = cityG;

		for (int i = 0; i < numCities; i++) {
			cities[i].remainingGas = cities[i].gas - cities[i].miles / 20.0;
			System.out.println(cities[i].symbol + ", " + cities[i].gas + ", " + cities[i].miles + "," +  cities[i].remainingGas);
		}

		for (int i = 0; i < numCities; i++) {
			double currGas = findCity(cities, numCities, i);
			System.out.println("city " + cities[i].symbol+ " gas at the end = " + currGas);
		}
	}

	public static void main(String[] args) {
		// create a new instance to start with
		Gasup gasup = new Gasup();
		gasup.test1();
	}
}
