package ch10;

import java.util.*;

public class Introsort {
	static int swap(int... args) {
		return args[0];
	}

	static void insertionsort(int[] a) {
		int n = a.length;
		for (int i = 1; i < n; i++) {
			int j = i;
			while (j > 0) {
				{
					if (a[j - 1] > a[j]) {
						//a[j] = swap(a[j - 1], a[j - 1] = a[j]);
						int tmp = a[j];
						a[j] = a[j - 1];
						a[j - 1] = tmp;
						--j;
					} else {
						break;
					}
				}
			}
		}
	}
	
	static void maxHeapify(int[] a, int n, int pIdx) {
		int left = 2 * pIdx + 1;
		int right = 2 * pIdx + 2;
		int largest = pIdx;
		
		if (left < n && a[left] > a[pIdx]) 
			largest = right;
		if (largest != pIdx) {
			//a[pIdx] = swap(a[largest], a[largest = a[pIdx]]);
			int tmp = a[pIdx];
			a[pIdx] = a[largest];
			a[largest] = tmp;
			maxHeapify(a, n, largest);
		}
	}
	
	static void heapsort (int[] a, int n) {
		for (int pIdx = (n - 1) / 2; pIdx >= 0; --pIdx)
			maxHeapify(a, n, pIdx);
		
		for (int i = n - 1; i > 0; --i) {
			//a[0] = swap(a[i], a[i] = a[0]);
			int tmp = a[0];
			a[0] = a[i];
			a[i] = tmp;
			--n;
			maxHeapify(a, n, 0);
		}
	}
	static int partition(int[] a, int start, int end) {
		int pivot = 0;
		if (start < end) {
			pivot = start;
			while (start < end) {
				while (a[start] <= a[pivot]) start++;
				while (a[end] > a[pivot]) end--;
				if (start < end) {
					//a[start] = swap(a[end], a[end] = a[start]);
					int tmp = a[start];
					a[start] = a[end];
					a[end] = tmp;
				}
			}
		}
		//a[end] = swap(a[pivot], a[pivot] = a[end]);
		int tmp = a[pivot];
		a[pivot] = a[end];
		a[end] = tmp;
		return pivot;
	}
	static void quicksort(int[] a, int start, int end) {
		if (start < end) {
			int q = partition(a, start, end);
			quicksort(a, start, q - 1);
			quicksort(a, q + 1, end);
		}
	}
	
	static void introsort(int[] a, int n) {
		int pivotIdx = partition(a, 0, n - 1);
		if (pivotIdx < 16)
			insertionsort(a);
		else if (pivotIdx > 2 * Math.log(n))
			heapsort(a, n);
		else 
			quicksort(a, 0, n - 1);
	}
	
	static void printArray(int[] a) {
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i] + " ");
			if (i > 20)  
				break;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		int N = 100000;
		int[] a = new int[N];
		int[] dupA= new int[N];
		
		Random rndm = new Random();
		
		for (int i = 0; i < N; i++) {
			int rndmInt = rndm.nextInt(10 * N);
			dupA[i] = rndmInt;
			a[i] = rndmInt;
		}
		
		System.out.println("sort an array with " + N  + " elements");
				
		//1. Arrays.sort
		long startTime = System.currentTimeMillis();
		Arrays.sort(a);
		System.out.println("Arrays.sort took " + (System.currentTimeMillis() - startTime) + " ms");
		printArray(a);
		
		//2. introsort
		startTime = System.currentTimeMillis();
		introsort(dupA, N);
		System.out.println("\nintrosort took " + (System.currentTimeMillis() - startTime) + " ms");
		printArray(a);
	}
}
