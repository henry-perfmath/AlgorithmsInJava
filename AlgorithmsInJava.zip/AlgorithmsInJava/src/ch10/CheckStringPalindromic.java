package ch10;

import java.util.*;
public class CheckStringPalindromic {

	static boolean checkPalindromic(String str) {
		char[] charArr = str.toCharArray();
		int n = charArr.length;
		for(int i = 0; i < n / 2; i++)
			if (charArr[i] != charArr[n - 1 - i])
				return false;
		
		return true;
	}
	public static void main(String[] args) {
		String str = "radar";
		System.out.println("input string: " + str);
		System.out.println("input string palindromic: " + checkPalindromic(str));
		
		str = "abba";
		System.out.println("\ninput string: " + str);
		System.out.println("input string palindromic: " + checkPalindromic(str));
		
		str = "ababba";
		System.out.println("\ninput string: " + str);
		System.out.println("input string palindromic: " + checkPalindromic(str));
	}
}
