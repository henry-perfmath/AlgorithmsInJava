package ch10;

import java.util.*;
public class MinNumToSum {
	int minItemsRecur(int a[], int n, int V)
	{
	   if (V == 0) return 0;

	   int minItems = Integer.MAX_VALUE;

	   for (int i = 0; i < n; i++)
		   if (a[i] <= V)
			   minItems = Math.min(minItems, 1 + minItemsRecur(a, n, V - a[i]));

	   return minItems ;
	}

	int minItemsDp(int a[], int n, int V) {

	    int[] minItems = new int[V + 1];
	    int[] included = new int[V + 1];

	    minItems[0] = 0;
	    for (int v = 1; v <= V; v++)
	    	minItems[v] = Integer.MAX_VALUE;

		for (int v = 1; v <= V; v++) {
			for (int i = 0; i < n; i++) {
				int sup_vi = v - a[i];
				if (sup_vi >= 0) {
					int sub_sol = 1 + minItems[sup_vi];
					if (sub_sol < minItems[v]) {
						minItems[v] = sub_sol;
						included[v] = a[i];
					}
				}
			}
		}

		System.out.println("\nitems included for V = " + V);
	    int  v = V;
	    while (v > 0) {
	    	System.out.print("included[" + v + "] = " + included[v] + " ");
	        v = v - included[v];
	    }
	    System.out.println();

	    return minItems[V];
	}

	void test1() {
	    int a[] =  {9, 4, 1};
	    int n = a.length;
	    int V = 12;
	    System.out.println("test1 (recur): " + minItemsRecur(a, n, V));
	}

	void test2() {
	    int a[] =  {9, 4, 1};
	    int n = a.length;
	    int V = 12;
	    System.out.println("test2 (dp): " + minItemsDp(a, n, V));
	}

	void test3() {
	    int a[] =  {25, 16, 9, 4, 1};
	    int n = a.length;
	    int V = 30;
	    System.out.println("test3 (dp): " + minItemsDp(a, n, V));
	}

	void test4() {
	    int a[] =  {1, 5, 10, 25};
	    int n = a.length;
	    int V = 30;
	    System.out.println("test4 (dp): " + minItemsDp(a, n, V));
	}

	public static void main(String[] args) {
		MinNumToSum mnts = new MinNumToSum();
		mnts.test1();
		mnts.test2();
		mnts.test3();
		mnts.test4();
	}
}
