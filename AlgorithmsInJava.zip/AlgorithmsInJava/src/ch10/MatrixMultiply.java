package ch10;

public class MatrixMultiply {
	void matrixMultiply(int M, int K, int N, int[][] a, int[][] b, int[][] c)
	{
		System.out.println("M K N:" + M + " " +  K + " " + N);

	    for (int i = 0; i < M; i++)
	    {
	        for (int j = 0; j < N; j++)
	        {
	            //c[i][j] = 0;
	            for (int k = 0; k < K; k++) {
	                c[i][j] += a[i][k] * b[k][j];
	            }
	        }
	    }
	}

	void test1() {
		int M = 2, K = 3, N = 2;

		int[][] a = {{1, 2, 3}, {4, 5, 6}};
		int[][] b = {{7, 8}, {9, 10}, {11, 12}};
		int[][] c = {{0, 0}, {0, 0}};
		//int M = a.length, K = b.length, N = c.length;
	    matrixMultiply (M, K, N, a, b, c);

	    // c = 58, 64, 139, 154
	    for (int i = 0; i < M; i++) {
	    	System.out.println();
	    	for (int j = 0; j < N; j++)
	    		System.out.print(c[i][j] + " ");
	    }
	    System.out.println();
	}
	public static void main(String[] args) {
		MatrixMultiply mm = new MatrixMultiply();
		mm.test1();
	}
}
