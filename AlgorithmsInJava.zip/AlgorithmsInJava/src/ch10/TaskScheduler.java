package ch10;

import java.util.*;
public class TaskScheduler {
	int waitTime;
	int[] scheduler(int a[]) {
		int n = a.length;
		Arrays.sort(a);
		int[] schedule = new int[n];
		for (int i = 0; i < n; i++) {
			schedule[i] = a[i];
			//if (i < (n - 1)) waitTime += a[i] * (n - 1 - i);
			waitTime += a[i] * (n - 1 - i);
		}
		return schedule;
	}

	void test1() {
		int serviceTime [] = {2, 5, 1, 3};

		int n = serviceTime.length;
		int[] schedule = scheduler(serviceTime); //

		System.out.println("minimized wait time = " + waitTime);
		for(int i = 0; i < n; i++) {
			System.out.print(schedule[i] + " ");
		}
		System.out.println();
	}
	public static void main(String[] args) {
		TaskScheduler ts = new TaskScheduler();
		ts.test1();
	}
}
