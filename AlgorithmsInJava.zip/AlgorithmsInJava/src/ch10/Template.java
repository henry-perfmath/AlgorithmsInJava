package ch10;

import java.util.*;
public class Template {

	public static void main(String[] args) {
		
	}
}
