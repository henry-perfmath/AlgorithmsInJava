package ch10;

import java.util.*;

public class SearchMaze {

	static void printSolution(int[][] sol) {
		int n = sol.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				System.out.print (sol[i][j] + " ");
			System.out.print(" -> ");
		}
		System.out.println();
	}

	static boolean isValid(int[][] maze, int x, int y) {
		int n = maze.length;
		if (x >= 0 && x < n && y >= 0 && y < n && maze[x][y] == 1)
			return true;

		return false;
	}

// (x0, y0) are start point
	static boolean solver(int[][] maze, int x0, int y0) {
		int[][] sol = { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };

		if (search(maze, x0, y0, sol) == false) {
			System.out.println("Solution doesn't exist for " + x0 + ", " + y0);
			return false;
		}

		System.out.println("Solution for: " + x0 + ", " + y0);
		printSolution(sol);
		return true;
	}

// (x, y): next move or destination
	static boolean search(int[][] maze, int x, int y, int[][] sol) {
		int n = maze.length;
		// done and return true
		if (x == n - 1 && y == n - 1) {
			sol[x][y] = 1;
			return true;
		}

		// Check if (x, y) within the maze
		if (isValid(maze, x, y)) {
			// pre-mark (x,y) good
			sol[x][y] = 1;

			/* try one step forward in x direction */
			if (search(maze, x + 1, y, sol) == true)
				return true;

			/* try one step down in y direction */
			if (search(maze, x, y + 1, sol) == true)
				return true;

			// mices failed so backtrack with unmarking
			sol[x][y] = 0;
			return false;
		}
		// (x, y): next move or destination
		return false;
	}

	public static void main(String[] args) {
		int[][] maze = { { 1, 0, 0, 0 }, { 1, 1, 0, 1 }, { 0, 1, 0, 0 }, { 1, 1, 1, 1 } };

		solver(maze, 0, 0);
		solver(maze, 0, 1);
		solver(maze, 1, 0);
	}
}
