package ch10;

public class BitMap {
	static int numLevels = 4;
	static int[][] bits = new int[numLevels][8];

	// level = 3; start = 2; n =3
	static void clearBits(int level, int start, int n) {
		for (int i = start; i < start + n; i++) {
			bits[level][i] = 0;
		}
		
		int startPidx = start / 2;
		int numParents = (start + n) / 2;
		while (level > 0) {
			--level;
			for (int i = startPidx; i < startPidx + numParents; i++) {
				bits[level][i] = 0;
			}
			
			startPidx /= 2;
			numParents /= 2;
		}
		
		printBits("after:");
	}

	public static void main(String[] args) {
		bits[0][0] = 0;
		bits[1][0] = 0; bits[1][1] = 1; 
		
		for(int i = 0; i < 4; i++) bits[2][i] = 1;
		for(int i = 0; i < 8; i++) bits[3][i] = 1;
		
		printBits("before:");
		clearBits(3, 2, 3);
	}
	
	static void printBits(String label) {
		System.out.println(label);
		int level = 0;
		while (level < numLevels) {
			int length = (int) Math.pow(2, level);
			System.out.print("level = " + level + ": ");
			for (int i = 0; i < length; i++) {
				System.out.print(bits[level][i] + "  ");

			}
			System.out.println("");
			level++;
		}
		System.out.println("");
	}
}
