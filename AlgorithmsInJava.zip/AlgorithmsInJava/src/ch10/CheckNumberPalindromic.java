package ch10;

public class CheckNumberPalindromic {

	static boolean checkPalindromic(int x) {
		if (x <= 0) return x == 0;
		
		int numDigits = (int) (Math.floor(Math.log10(x) + 1));
		int msdMask = (int) Math.pow(10, numDigits - 1);
		
		System.out.println("numDigits = " + numDigits + ", msdMask = " + msdMask);
		for (int i = 0; i < numDigits / 2; i++) {
			if (x / msdMask != x % 10)
				return false;
			x %= msdMask;
			x /= 10;
			msdMask /= 100;
		}
		return true;
	}
	public static void main(String[] args) {
		int x = 151751;
		System.out.println("input number: " + x);
		System.out.println("input number palindromic: " + checkPalindromic(x));
		
		x = 157751;
		System.out.println("\ninput number: " + x);
		System.out.println("input number palindromic: " + checkPalindromic(x));
	}
}
