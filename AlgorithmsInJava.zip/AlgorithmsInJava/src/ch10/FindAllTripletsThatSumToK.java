package ch10;

import java.util.*;
public class FindAllTripletsThatSumToK {
	static void findTriplets(int[]a, int k) {
		Arrays.sort(a);
		int n = a.length;
		for (int i = 0; i < n; i++) {
			int start =  i + 1;
			int end = n - 1;
			while (start < end) {
				int sum = a[i] + a[start] + a[end];
				if (sum == k) {
					System.out.println(a[i] + " + " + a[start] + " + " + a[end] + " = " + sum);
					start++;
					end--;
				} else if (sum < k)
					start++;
				else
					end--;
			}
		}
	}
	public static void main(String[] args) {
		int[] a = {1, 4, 45, 6, 10, 8, 12, 0, 16};
		int k = 22;
		findTriplets(a, k);
	}
}
