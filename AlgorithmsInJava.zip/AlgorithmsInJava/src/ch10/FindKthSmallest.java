package ch10;

import java.util.*;

public class FindKthSmallest {

	static int findKthSmallest (int[]a, int k) {
		return a[k - 1];
	}
	
	static void heapify(int[] a, PriorityQueue<Integer> pQueue) {
		for (int i = 0; i < a.length; i++) {
			pQueue.add(a[i]);
		}
	}
	static int findKthSmallestInPQ (int[]a, int k) {
		int kthSmallest = 0;
		PriorityQueue<Integer> pQueue = new PriorityQueue<Integer>();
		
		heapify(a, pQueue);
		for (int i = 0; i < k; i++) {
			kthSmallest = pQueue.remove();
		}
		return kthSmallest;
	}
	public static void main(String[] args) {
		int[] a = {53, 56, 55, 12, 22, 16, 30, 35, 39, 42, 45, 48, 50};
		int k = 5;
		System.out.println("# " + k + " smallest = " + findKthSmallestInPQ(a, k));
	}
}
