package ch10;

public class Fibonacci {

	static int fibonacci(int n) {
		if (n <= 1) {
			return n;
		}

		int fMinus2 = 0, fMinus1 = 1, f = 0;
		for (int i = 2; i <= n; ++i) {
			f = fMinus2 + fMinus1;
			fMinus2 = fMinus1;
			fMinus1 = f;
		}
		return f;
	}

	public static void main(String[] args) {
		int n = 11; // 89
		System.out.println("fibonacci(" + n + "):" + fibonacci(n));
	}
}
