package ch10;

import java.util.*;
public class SortA2DMatrix {

	static void printMatrix(int[][] matrix) {
		int n = matrix.length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				System.out.print(matrix[i][j] + "  ");
			System.out.println();
		}
		System.out.println();
	}
	public static void main(String[] args) {
		int n = 9;
		int[][] matrix = new int[9][9];
		Random rdnm = new Random();
		
		int[] a = new int[n*n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				matrix[i][j] = rdnm.nextInt(2 * n);
				a[j + i * n] = matrix[i][j];
			}
		}
		// print
		printMatrix(matrix);
		Arrays.sort(a);
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				matrix[i][j] = a[j + i * n];
			}
		}
		printMatrix(matrix);
	}
}
