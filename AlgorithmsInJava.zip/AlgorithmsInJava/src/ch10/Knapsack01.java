package ch10;

public class Knapsack01 {
	int knapsack(int W, int w[], int v[], int n)
	{
	   if (n == 0 || W == 0)
	       return 0;

	   if (w[n - 1] > W)
	       return knapsack(W, w, v, n - 1);

	   else {
		   return Math.max(knapsack(W, w, v, n - 1),
				      knapsack(W - w[n - 1], w, v, n - 1) + v[n - 1]);
	   }
	}

	int knapsackDp(int W, int w[], int v[], int n)
	{
	   int[][] mv = new int[n + 1][W + 1];

	   for (int i = 0; i <=n; i++)
		   for (int ww = 0; ww <= W; ww++)
			   mv[i][ww] = 0;

	   for (int i = 1; i <= n; i++) {
	       for (int ww = 1; ww <= W; ww++){
	    	   mv[i][ww]  = mv[i - 1][ww];

	    	   int weightOff = ww - w[i - 1];
	    	   if (weightOff >= 0) {
	        	   mv[i][ww] = Math.max(mv[i][ww],  v[i - 1] + mv[i - 1][weightOff]);
	           }
	       }
	   }

	   return mv[n][W];
	}

	void test1() {
	    int w[] = {1, 4, 9};
	    int v[] = {1, 1, 1};

	    int W = 12;
	    int n = v.length;
	    System.out.println("test1 (recur): " +  knapsack(W, w, v, n));
	    System.out.println("test1 (dp): " + knapsackDp(W, w, v, n));
	}

	void test2() {
	    int w[] = {12, 2, 1, 4, 1};
	    int v[] = {4, 2, 1, 10, 2};

	    int W = 9;
	    int n = v.length;
	    System.out.println("test2 (recur): " + knapsack(W, w, v, n));
	    System.out.println("test2 (dp): " + knapsackDp(W, w, v, n));
	}

	public static void main(String[] args) {
		Knapsack01 knapsack01 = new Knapsack01();
		knapsack01.test1();
		knapsack01.test2();
	}
}
