package ch10;

import java.util.*;

public class FindFirstKClosest {

	static String findFirstKClosest(int[] array, int k, int x) {
		int[] a = array;
		System.out.println("input array: " + Arrays.toString(a));
		String firstKClosestStr = "";
		int n = a.length;
	
		// before left end
		if (x < a[0]) {
			for (int i = 0; i < k; i++)
				firstKClosestStr += a[i] + " ";
			return firstKClosestStr;
		}
		
		// after right end
		if (x > a[n - 1]) {
			for (int i = n - k ; i < n; i++)
				firstKClosestStr += a[i] + " ";
			return firstKClosestStr;
		}
		
		int pivot = -1;
		for (int i = 0; i < n; i++) {
			if (a[i] >= x) {
				pivot = i;
				break;
			}
		}

		int count = 0;
		int left = pivot - 1;
		int right = pivot + 1;
		while (count < k) {
			count++;
			if ((right > n - 1) || (a[right] - a[pivot]) > (a[pivot] - a[left])) {
				firstKClosestStr += a[left] + " ";
				if (left > 0) { // in range
					left--;
				} else { // add the remaining
					for (int i = right; i < right + k - count; i++)
						firstKClosestStr += a[i] + " ";
					break;
				}
			} else if ((left < 0) || (a[right] - a[pivot]) < (a[pivot] - a[left])) {
				firstKClosestStr += a[right] + " ";
				if (right < n - 1) { // in range
					right++;
				} else { // add the remaining
					for (int i = left; i > left - (k - count); i--)
						firstKClosestStr += a[i] + " ";
					break;
				}
			}
		}

		return firstKClosestStr;
	}

	public static void main(String[] args) {
		int[] a = {12, 16, 22, 30, 35, 39, 42, 45, 48, 50, 53, 56, 55};

		Arrays.sort(a);
		String firstKClosestStr = "";
		int k = 4;
		int x = 0; 

		x = -156; // far left
		firstKClosestStr = findFirstKClosest(a, k, x);
		System.out.println(k + " closest to x = " + x + ": " + firstKClosestStr);
		
		x = 156; // far right
		firstKClosestStr = findFirstKClosest(a, k, x);
		System.out.println(k + " closest to x = " + x + ": " + firstKClosestStr);
		
		x = 35; // in-between
		firstKClosestStr = findFirstKClosest(a, k, x);
		System.out.println("k = 4, x = " + x + ": " + firstKClosestStr);

		x = 16; // skewed to left
		firstKClosestStr = findFirstKClosest(a, k, x);
		System.out.println("k = 4, x = " + x + ": " + firstKClosestStr);
		
		x = 55; // skewed to right
		firstKClosestStr = findFirstKClosest(a, k, x);
		System.out.println("k = 4, x = " + x + ": " + firstKClosestStr);		
	}
}
