package ch10;

public class FindMinWeightPathInATriangle {
	static int getMinWeight(int n, int a[]) {

		int levels = (int) Math.sqrt(2 * n);
		int level = 1;
		int idx = 0;
		int minWeight = a[0];
		System.out.println("level = " + level + ", minWeight = " + a[idx]);

		while (level < levels) {
			idx += level;
			if (a[idx] > a[idx + 1]) {
				minWeight += a[idx++];
			}
			System.out.println("level = " + level + ", minWeight = " + a[idx]);
			level++;
		}
		return minWeight;
	}

	public static void main(String[] args) {
		int a[] = {2, 4, 4, 8, 5, 6, 4, 2, 6, 2, 1, 5, 2, 3, 4};
		int n = a.length;
		System.out.println("Found min weight = " + getMinWeight(n, a));
	}
}
