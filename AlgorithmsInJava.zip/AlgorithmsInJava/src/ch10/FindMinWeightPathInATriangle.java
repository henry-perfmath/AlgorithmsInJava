package ch10;

public class FindMinWeightPathInATriangle {
	static int[] getMinWeight (int[] a, int level, int[] x) {
		int idx0 = x[0] + level; // jump level elements
		int idx1 = idx0 + 1;
		x[0] = idx0;
		x[1] = a[idx0];
		if (a[idx1] < a[idx0]) {
			x[0] = idx1;
			x[1] = a[idx1];
		}
		System.out.println("level = " + level + ", minWeightValue = " + a[x[0]]);
		return x;
	}
	static int find(int n, int a[]) {

		int minWeight = a[0];
		int levels = (int) Math.sqrt(2 * n);
		int level = 1;
		int idx = 0;
		System.out.println("level0 = " + level + ", minWeightValue = " + a[idx]);
		int[] x = new int[2]; // {idx and minWeight}
		while (level < levels) {
			x = getMinWeight(a, level, x);
			minWeight += x[1];
			level++;
		}
		return minWeight;
	}

	static void test1() {
		int a[] = {2, 4, 4, 8, 5, 6, 4, 2, 6, 2, 1, 5, 2, 3, 4};
		int n = a.length;
		System.out.println("Found min weight = " + find(n, a));
	}
	public static void main(String[] args) {
		test1();
	}
}
