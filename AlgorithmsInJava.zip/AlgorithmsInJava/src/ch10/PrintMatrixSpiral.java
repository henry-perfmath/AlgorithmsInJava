package ch10;

import java.util.*;
public class PrintMatrixSpiral {
	
	static void printSpiral(int offset, int[][]a) {
		int n = a.length;
		if (n % 2 == 0 && offset >= n / 2) return;
		if (n % 2 == 1 && offset > n / 2) return;
		
		//print upper
		for (int j = offset; j < n - offset; j++)
			System.out.print(a[offset][j] + " ");
		
		//print right
		for (int i = offset + 1; i < n - offset; i++)
			System.out.print(a[i][n - offset - 1] + " ");
		
		//print bottom
		for (int j = n - 2 - offset; j >= offset; j--)
			System.out.print(a[n - 1 - offset][j] + " ");
		
		//print left
		for (int i = n - 2 - offset; i > offset; i--)
			System.out.print(a[i][offset] + " ");

		offset++;
		printSpiral(offset, a);
	}

	public static void main(String[] args) {
		int[][] maxtrix = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
		printSpiral(0, maxtrix);
	}
}
