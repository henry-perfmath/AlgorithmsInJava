package ch10;

import java.util.*;
public class ArrayMultiply {
	void arrayMultiply(int a[], int b[])
	{
		int n = a.length;
		b[0] = 1;

		int sub = 1;
		for (int i = 1; i < n; i++) {
			sub *= a[i - 1];
			b[i] = sub;
		}

		sub = 1;
		for (int i = n - 1; i > 0; i--) {
			sub *= a[i];
			b[i - 1] *= sub;
		}
	}

	public static void main(String[] args) {
		ArrayMultiply am = new ArrayMultiply();
		int a[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		int n = 9;
		int[] b = new int [9];
		
		int N = 10000000;

		long start = System.currentTimeMillis();
		for (int i = 0; i < N; i++)
			am.arrayMultiply(a, b);
		long duration = System.currentTimeMillis() - start;
		System.out.println(N + " iterations took " +  duration + " ms");

		System.out.println("result for last iteration: ");
		for (int i = 0; i < n; i++) {
			System.out.print(b[i] + " ");
		}
		System.out.println();
	}
}
