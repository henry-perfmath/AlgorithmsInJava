package ch10;

import java.util.LinkedList;

public class ReverseLinkedList {
	static LinkedList<Node> list;

	static class Node {
		int data;
		Node next;

		Node(int d) {
			this.data = d;
			next = null;
		}
	}

	public static void traverse() {
		Node head = list.get(0);
		while (head != null) {
			System.out.print(head.data + " ");
			head = head.next;
		}
		System.out.println();
	}

	public static void reverse1() {
		int n = list.size();
		for (int i = 0; i < n / 2; i++) {
			Node node1 = list.get(i);
			Node node2 = list.get(n - 1 - i);
			int tmp = node1.data;
			node1.data = node2.data;
			node2.data = tmp;
		}
	}

	public static void reverse2() {
		Node curr = list.get(0);
		Node prev = null;
		Node next = null;

		while (curr != null) {
			next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
		}
		list.set(0, prev);
	}

	public static void main(String[] args) {

		// 1. make list
		list = new LinkedList<Node>();
		Node cursor = new Node(0);
		list.add(cursor);

		int n = 10;
		for (int i = 1; i < n; i++) {
			Node node = new Node(i);
			list.add(node);
			cursor.next = node;
			cursor = node;
		}

		// 2. traverse newly made list
		System.out.print("input list: ");
		traverse();

		// 3. reverse newly made list with swapping
		reverse1();
		System.out.print("reversed (1) list: ");
		traverse();

		// 4. reverse reversed list next pointer
		reverse2();
		System.out.print("reversed (2) list: ");
		traverse();
	}
}
