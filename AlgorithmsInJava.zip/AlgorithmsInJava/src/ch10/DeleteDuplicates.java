package ch10;

public class DeleteDuplicates {
	static int deleteDuplicates(int[] a) {
		int k = 1;
		for (int i = 1; i < a.length; i++) {
			if (a[i - 1] != a[i]) {
				a[k++] = a[i];
			}
		}

		return k;
	}
	public static void main(String[] args) {
		int[] a = {2, 3, 5, 5, 7, 11, 11, 11, 13};
		int n = deleteDuplicates(a);
		for (int i = 0; i < n; i++) {
			System.out.print(a[i] + " ");
		}
	}
}
