package ch10;

public class DupNumbers {
	static void printDuplicate(int[] a)
	{
	  int n = a.length;
	  System.out.println("The repeating elements are:");
	  for (int i = 0; i < n; i++)
	  {
	    if (a[Math.abs(a[i])] >= 0)
	      a[Math.abs(a[i])] = -a[Math.abs(a[i])];
	    else
	      System.out.print(Math.abs(a[i]) + " ");
	  }
	  System.out.println();
	}

	public static void main(String[] args) {
		  int a[] = {1, 2, 1, 3, 4, 4, 5, 6, 7, 2, 1, 8, 3, 1, 3, 2, 10, 2, 4, 12};
		  printDuplicate(a);
	}
}
