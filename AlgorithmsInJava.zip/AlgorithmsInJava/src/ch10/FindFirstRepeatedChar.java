package ch10;

import java.util.HashSet;

public class FindFirstRepeatedChar {
	static char findFirstRepeatedChar (String str) {
		char[] charArr = str.toCharArray();
		HashSet<Character> set = new HashSet<Character>();
		for (int i = 0; i < charArr.length; i++) {
			if (set.contains(charArr[i])) {
				return charArr[i];
			} else {
				set.add(charArr[i]);
			}
		}
		return '\0'; // empty
	}
	
	public static void main(String[] args) {
		String str = "This is a test";
		char firstrepeatedChar = findFirstRepeatedChar(str);
		System.out.println("firstrepeatedChar = " + firstrepeatedChar);
		
		str = "abc";
		firstrepeatedChar = findFirstRepeatedChar(str);
		System.out.println("firstrepeatedChar = " + firstrepeatedChar);
		
		str = "a0b0c0";
		firstrepeatedChar = findFirstRepeatedChar(str);
		System.out.println("firstrepeatedChar = " + firstrepeatedChar);
	}
}
