package ch10;

public class SearchA2DSortedMatrix {

	static boolean search(int[][] a, int x) {
		boolean found = false;
		int rows = a.length;
		int columns = a[0].length;
		System.out.println("rows = " + rows + " columns = " + columns);
		
		int i = 0, j = columns - 1;

		while (i < rows && j >= 0) {
			if (a[i][j] == x) {
				found = true;
				break;
			} else if (x < a[i][j]) {
				j--;
			} else {
				i++;
			}
		}
		
		return found;
	}
	
	static boolean search0(int[][] a, int x) {
		boolean found = false;
		int rows = a.length;
		int columns = a[0].length;
		System.out.println("rows = " + rows + " columns = " + columns);
		
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				if (a[i][j] == x) {
					found = true;
				}
			}
		}
		return found;
	}
	
	public static void main(String[] args) {
		int[][] matrix = {{10, 20, 30, 40},
						  {15, 25, 35, 45},
						  {27, 29, 37, 48}};
		
		int x = 20;
		if (search(matrix, x)) {
			System.out.println(x + " found");
		} else {
			System.out.println(x + " not found");
		}	
		
		x = 29;
		if (search(matrix, x)) {
			System.out.println(x + " found");
		} else {
			System.out.println(x + " not found");
		}	
	}
}
