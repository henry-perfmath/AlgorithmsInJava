package ch10;

import java.util.*;
public class ComputeIOU {
	static float computeIou(int[]rect1, int[] rect2) {
		int r1X = rect1[0], r1Y = rect1[1], r1W = rect1[2], r1H = rect1[3];
		int r2X = rect2[0], r2Y = rect2[1], r2W = rect2[2], r2H = rect2[3];
		
		// condition: rect1's upper right corner is within rect2
		boolean c1 = r1X + r1W > r2X && r1X < r2X + r2W;
		boolean c2 = r1Y + r1H > r2Y && r1Y < r2Y + r2H;
		
		float iou = 0.0f;
		if (c1 && c2) {
			System.out.println("two rects intersect");
			int iouNum = (r1X + r1W - r2X) * (r1Y + r1H - r2Y);
			int iouDen = r1W * r1H + r2W * r2H - iouNum;
			iou = 1.0f * iouNum / iouDen;
		} else {
			System.out.println("two rects do not intersect");
		}
		return iou;
	}
	public static void main(String[] args) {
		int[] rect1 = {0, 0, 3, 3}; // x, y, width and height
		int[] rect2 = {1, 1, 4, 4};
		
		float iou = computeIou(rect1, rect2);
		System.out.println("iou: = " + iou);
	}
}
