package ch10;

public class BinarySearch {

	static int bsIterative(int[] a, int left, int right, int x) {
		while (left <= right) {
			int mid = (left + right) / 2;
			System.out.println("mid = " + mid);
			if (a[mid] == x) {
				return mid;
			}

			if (a[mid] > x) {
				right = mid--;
			} else {
				left = mid++;
			}
		}
		return -1;
	}

	static int bsRecursive(int[] a, int left, int right, int x) {
		int mid = (left + right) / 2;
		System.out.println("mid = " + mid + " a[" + mid + "] = " + a[mid]);
		if (a[mid] == x) {
			return mid;
		}
		
		if (left <= right) {
			if (a[mid] > x) {
				return bsRecursive (a, left, mid - 1, x);
			} else {
				return bsRecursive (a, mid + 1, right, x);
			}
		}

		return -1;
	}
	
	public static void main(String[] args) {
		int[] a = {2, 3, 4, 10, 40};
		int x = 10;
		int n = a.length;
		
		System.out.println("test iterative:");
		int result = bsIterative(a, 0, n - 1, x);
		if (result != -1 ) {
			System.out.println(result + ": " + x + " is found");
		} else {
			System.out.println(result + ": " + x + " is not found");
		}
		
		System.out.println("\ntest irecursive:");
		result = bsRecursive(a, 0, n - 1, x);
		if (result != -1 ) {
			System.out.println(result + ": " + x + " is found");
		} else {
			System.out.println(result + ": " + x + " is not found");
		}
	}
}
