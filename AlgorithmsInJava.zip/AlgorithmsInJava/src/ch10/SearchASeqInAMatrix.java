package ch10;

import java.util.Arrays;

public class SearchASeqInAMatrix {
	static boolean search(int[][] a, int[] b) {
		int n = a.length;
		int m = b.length;
		int i = 0, j = 0, k = 0;
		if (a[i][j] != b[k]) {
			return false;
		} else {
			System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			k++;
		}

		while (i < n && j < n) {
			if ((j + 1) < n && a[i][j + 1] == b[k]) {
				j++;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if ((i + 1) < n && a[i + 1][j] == b[k]) {
				i++;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if ((i > 0) && (a[i - 1][j] == b[k])) {
				i--;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if (j > 0 && (a[i][j - 1] == b[k])) {
				j--;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if (k < m) {
				System.out.println("b[k] = " + b[k] + " not found ");
				return false;
			}
			k++;
			if (k == m) {
				return true;
			}
		}
		return false;
	}

	static void test1() {
		// initialize a matrix and get the dimension
		int[][] a = { { 1, 2, 3 }, { 3, 4, 5 }, { 5, 6, 7 } };

		int b[] = { 1, 3, 4, 6 };
		System.out.println("found = " + search(a, b) + " for seq. " + Arrays.toString(b) + "\n");
	}

	static void test2() {
		// initialize a matrix and get the dimension
		int[][] a = { { 1, 2, 3 }, { 3, 4, 5 }, { 5, 6, 7 } };

		int b[] = { 1, 3, 4, 8 };
		System.out.println("found = " + search(a, b) + " for seq. " + Arrays.toString(b) + "\n");
	}

	public static void main(String[] args) {
		test1();
		test2();
	}
}
