package ch10;

public class SearchASeqInAMatrix {
	static int search(int[][] a, int[] b) {
		int n = a.length;
		int m = b.length;
		int i = 0, j = 0, k = 0;
		if (a[i][j] != b[k]) {
			return 0;
		} else {
			System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			k++;
		}

		while (i < n && j < n) {
			if ((j + 1) < n && a[i][j + 1] == b[k]) {
				j++;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if ((i + 1) < n && a[i + 1][j] == b[k]) {
				i++;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if ((i > 0) && (a[i - 1][j] == b[k])) {
				i--;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if (j > 0 && (a[i][j - 1] == b[k])) {
				j--;
				System.out.println("b[k] = " + b[k] + " at i = " + i + " j = " + j);
			} else if (k < m) {
				return 0;
			}
			k++;
			if (k == m) {
				return 1;
			}
		}
		return 0;
	}

	static void test1() {
		// initialize a matrix and get the dimension
		int[][] a = { { 1, 2, 3 }, { 3, 4, 5 }, { 5, 6, 7 } };
		int n = a.length;
		System.out.println("n = " + n);

		int b[] = { 1, 3, 4, 6 };
		System.out.println("found = " + search(a, b));
	}

	static void test2() {
		// initialize a matrix and get the dimension
		int[][] a = { { 1, 2, 3 }, { 3, 4, 5 }, { 5, 6, 7 } };
		int n = a.length;
		System.out.println("n = " + n);

		int b[] = { 1, 3, 4, 2 };
		System.out.println("found = " + search(a, b));
	}

	public static void main(String[] args) {
		test1();
		test2();
	}
}
