package ch10;

public class CoinCount {
	int countRecur( int a[], int n, int V )
	{
	    if (V == 0) return 1;
	    //if (V < 0 || (n <= 0 && V >= 1)) return 0;
	    if (V < 0 || (n <= 0)) return 0;

	    return countRecur(a, n - 1, V) + countRecur(a, n, V - a[n - 1]);
	}

	int count2d( int a[], int n, int V )
	{
	    int[][] count = new int[V + 1][n];

	    for (int v = 0; v < V + 1; v++)
	    	for (int i = 0; i < n; i++)
	    		count[v][i] = (v == 0) ? 1 : 0;

	    for (int v = 1; v < V + 1; v++) {
	    	for (int i = 0; i < n; i++) {

	        	if (v >= a[i]) count[v][i] = count[v - a[i]][i];
	        	if (i >= 1) count[v][i] += count[v][i - 1];

	        }
	    }
	    return count[V][n - 1];
	}

	int count1d( int a[], int n, int V ){

	    int[] count = new int[V + 1];

	    count[0] = 1;
	    for (int v = 1; v <= V; v++)
	    	count[v] = 0;

	    for(int i = 0; i < n; i++)
	        for(int v = a[i]; v <= V; v++)
	            count[v] = count[v] + count[v - a[i]];

	    return count[V];
	}

	void test1() {
	    int a[] = {1, 5, 10};
	    int n = a.length;
	    int V = 13;
	    System.out.println("test1: countRecur: " + countRecur(a, n, V));
	}

	void test2() {
	    int a[] = {1, 5, 10};
	    int n = a.length;
	    int V = 13;
	    System.out.println("test2: count2d: " + count2d(a, n, V));
	}

	void test3() {
	    int a[] = {1, 5, 10};
	    int n = a.length;
	    int V = 13;
	    System.out.println("test3: count1d: " + count1d(a, n, V));
	}

	public static void main(String[] args) {
		CoinCount cc = new CoinCount();
		cc.test1();
		cc.test2();
		cc.test3();
	}
}
