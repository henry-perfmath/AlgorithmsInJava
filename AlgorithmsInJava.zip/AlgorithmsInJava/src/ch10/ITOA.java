package ch10;

public class ITOA {

	static void itoa() {
		int m = 12345;
		int n = -12345;
		
		String mStr = Integer.toString(m);
		String nStr = Integer.toString(n);

		System.out.println(mStr);
		System.out.println(nStr);
	}
	
	static void atoi() {
		String mStr = "12345";
		String nStr = "-12345";
		
		int m = Integer.parseInt(mStr);
		int n = Integer.parseInt(nStr);

		System.out.println(m);
		System.out.println(n);
	}
	
	public static void main(String[] args) {
		itoa();
		atoi();
	}
}
