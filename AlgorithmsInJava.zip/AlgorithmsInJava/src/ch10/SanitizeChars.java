package ch10;

import java.util.*;
public class SanitizeChars {
	char flipChar(char ch) {
		return Character.isLowerCase(ch) ? Character.toUpperCase(ch) : Character.toLowerCase(ch);
	}

	// in-place with O(n) time and O(1) space
	char[] sanitize(char[] a) {
		int n = a.length;
		System.out.println("sanitize: n = " + n + " " + Arrays.toString(a));
		
		int i = 0, k = 0;
		while ( i < n - 1) {
			if (a[i] == flipChar(a[i + 1])) { // forward looking
				i = i + 2; // jump by 2
			} else if  (k > 0 && a[i] == flipChar(a[k - 1])) { // backward looking
				k = k - 1; // k goes back by 1 as the slot for the next new char
				i++;
			} else {
				a[k++] = a[i++]; // just copy data from index i to k
			}
		}
		// take care of the last char
		if (i <= n - 1) { // avoid array out of bounds
			a[k] = a[i];
		}
		
		char[] b = new char[k + 1];
		for (int j = 0; j <= k; j++)
			b[j] = a[j];
		return b;
	}

	void test(String str) {
		char[] charArray = str.toCharArray();
		int n = charArray .length;
		System.out.print("input str: " + str + " n = " + n);
		System.out.println();
		System.out.println("after: " + Arrays.toString(sanitize(charArray)).replaceAll(", ", "") + "\n");
	}

	public static void main(String[] args) {
		SanitizeChars sc = new SanitizeChars();
		String str = "abcCBppQQTtzz";
		sc.test(str);
		
		str = "abcCBppQQTt";
		sc.test(str);
	}
}
