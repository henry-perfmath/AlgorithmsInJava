package ch10;

import java.util.Arrays;

public class SelectionSort {
	public static void main(String[] args) {
		int[] a = {0, 29, 24, 16, 3, 3, 3, 29, 27, 16};
		System.out.println("Before: " + Arrays.toString(a));
		selectionSort (a);
		System.out.println("After: " + Arrays.toString(a));
	}
	
	private static void selectionSort(int[] a) {
		int n = a.length;
		for (int i = 0; i < n - 1; i++) {
			
			//1. find inIndex
			int currElement = a[i];
			int minIndex = i;
			for (int j = i + 1; j < n; j++) {
				if (a[j] < a[minIndex]) {
					minIndex = j;
				}
			}
			
			 //2. swap if needed 
			if (a[minIndex] < currElement) {
				a[i] = a[minIndex];
				a[minIndex] = currElement;
			}
		}
	}
}