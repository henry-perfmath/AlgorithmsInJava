package ch10;

public class CountNumOfWaysTraversingAMatrix {

	static int numOfSeqs2D(int m, int n) {

		int[][] seqs = new int[m][n];
		for (int i = 0; i < m; i++)
			seqs[i][0] = 1;
		for (int j = 0; j < n; j++)
			seqs[0][j] = 1;
		for (int i = 1; i < m; i++) {
			for (int j = 1; j < n; j++) {
				seqs[i][j] = seqs[i - 1][j] + seqs[i][j - 1];
			}
		}

		return seqs[m - 1][n - 1];
	}

	static int numOfSeqsDiagonal(int m, int n) {

		int[][] seqs = new int[m][n];
		for (int i = 0; i < m; i++)
			seqs[i][0] = 1;
		for (int j = 0; j < n; j++)
			seqs[0][j] = 1;
		for (int i = 1; i < m; i++) {
			for (int j = 1; j < n; j++) {
				seqs[i][j] = seqs[i - 1][j] + seqs[i][j - 1] + seqs[i - 1][j - 1];
			}

		}
		return seqs[m - 1][n - 1];
	}

	static int numOfSeqs1D(int m, int n) {
		if (n == 0)
			return 0;

		int[] seqs = new int[n];
		seqs[0] = 1;

		for (int i = 1; i < n; i++) {
			seqs[i] = 0;
		}

		for (int i = 0; i < m; i++) {
			for (int j = 1; j < n; j++)
				seqs[j] = seqs[j - 1] + seqs[j];
		}

		return seqs[n - 1];
	}

	public static void main(String[] args)
	{
		int N = 11;
		System.out.println("number of seqs 2d:\n");
		for (int i = 1; i < N; i++) {
			System.out.println("i = " + i + ": " + numOfSeqs2D(i, i));
		}

		System.out.println("number of seqs with diagonal:\n");
		for (int i = 1; i < N; i++) {
				System.out.println("i = " + i + ": "  + numOfSeqsDiagonal(i, i));
		}

		System.out.println("number of seqs 1d:\n");
		for (int i = 1; i < N; i++) {
			System.out.println("i = " + i+ ": "  + numOfSeqs1D(i, i));
		}
	}
}
