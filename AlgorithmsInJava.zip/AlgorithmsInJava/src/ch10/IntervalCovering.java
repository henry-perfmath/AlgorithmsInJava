package ch10;

import java.util.*;
public class IntervalCovering {
	private class Interval {
		int start;
		int end;
		public Interval(int start, int end) {
			super();
			this.start = start;
			this.end = end;
		}
		
		int getEnd() {
			return end;
		}
	};

	void printIntervals(Interval[] intervals) {
		for (int i = 0; i < intervals.length; i++) {
			System.out.println("i = " + i + ": [" + intervals[i].start + ", " + intervals[i].end + "]");
		}
	}
	int[] intervalCovering(Interval[] intervals) {
		int n = intervals.length;
		int[] visitTimes = new int[n];
		int k = 0;
		visitTimes [0] = intervals[0].end; // select the 1st visit time

		for (int i = 1; i < n; i++)
			visitTimes[i] = -1;
		// sort by end time. need a getter
		Arrays.sort(intervals, Comparator.comparing(Interval::getEnd)); 
		System.out.println("\nafter sorting:\n");
		printIntervals(intervals);

		for (int i = 0; i < n - 1; i++) {
			if(intervals[i + 1].start <= visitTimes [k]) {
				continue; // ok if the next job already started before the current visit time
			} else { // if the next job has not started, that will be the next visit time
				k++;
				visitTimes [k] = intervals[i + 1].start;
			}
		}

		return visitTimes;
	}

	void test1() {
		System.out.println("test1:");
		int n = 4;
		Interval[] intervals = new Interval[n];
		intervals[0] = new Interval(0, 3);
		intervals[1] = new Interval(2, 6);
		intervals[2] = new Interval(3, 4);
		intervals[3] = new Interval(6, 9);

		printIntervals(intervals);
		int[] visitTimes = intervalCovering(intervals);

		System.out.println("\nvisit times: ");
		for (int i = 0; i < n; i++)
			if (visitTimes[i] > 0) System.out.print(visitTimes[i] + " ");
		System.out.println();
	}

	void test2() {
		System.out.println("\ntest2:");
		int n = 5;
		Interval[] intervals = new Interval[n];
		intervals[0] = new Interval(0, 3);
		intervals[1] = new Interval(2, 6);
		intervals[2] = new Interval(3, 4);
		intervals[3] = new Interval(6, 9);
		intervals[4] = new Interval(4, 5);

		printIntervals(intervals);
		int[] visitTimes = intervalCovering(intervals);

		System.out.println("visit times: ");
		for (int i = 0; i < n; i++)
			if (visitTimes[i] > 0) System.out.print(visitTimes[i] + " ");
		System.out.println();
	}

	public static void main(String[] args) {
		IntervalCovering  ic = new IntervalCovering();
		ic.test1();
		ic.test2();
	}
}
