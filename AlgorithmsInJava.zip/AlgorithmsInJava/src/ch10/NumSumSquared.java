package ch10;

import java.util.*;
public class NumSumSquared {
	static int getMinItems(int n)
	{
		if (n < 1)
			return 0;

		int minItems = Integer.MAX_VALUE;
		int maxBase = (int) Math.sqrt(n);

		while (maxBase > 0)
		{
			int items = 0;
			int sum = n;
			int base = maxBase;

			while (sum > 0)
			{
				int x = sum / (base * base);
				items += x;
				sum = sum - x * base * base;
				--base;
			}

			if (items < minItems)
				minItems = items;
			maxBase--;
		}
		
		return minItems;
	}

	static int minItemsRecur(int a[], int n, int V)
	{
	   if (V == 0) return 0;

	   int minItems = Integer.MAX_VALUE;

	   for (int i = 0; i < n; i++)
		   if (a[i] <= V)
			   minItems = Math.min(minItems, 1 + minItemsRecur(a, n, V - a[i]));
		
	   return minItems ;
	}

	static int minItemsDp(int a[], int n, int V) {
	    int[] minItems = new int[V + 1];

	    minItems[0] = 0;
	    for (int v = 1; v <= V; v++)
	    	minItems[v] = Integer.MAX_VALUE;

		for (int v = 1; v <= V; v++) {
			for (int i = 0; i < n; i++) {
				int sup_vi = v - a[i];
				if (sup_vi >= 0) {
					int sub_sol = 1 + minItems[sup_vi];
					if (sub_sol < minItems[v]) {
						minItems[v] = sub_sol;
					}
				}
			}
		}
	    return minItems[V];
	}

	static void test(int V, int method) {
		int maxBase = (int) Math.sqrt(V);
		int[] a = new int[maxBase];
		for (int i = maxBase; i >= 1; i--) {
			a[i - 1] = i * i;
			//System.out.print(" i = " + i + " a[" + (i - 1) + "] = " + a[i - 1]);
		}
		
		int minItems = 0;
		System.out.println();
		long startTime = System.nanoTime();
		if (method == 1) {
			minItems = getMinItems(V);
		} else if (method == 2) {
			minItems = minItemsRecur(a, maxBase, V);
		} else if (method == 3)  {
			minItems = minItemsDp(a, maxBase, V);
		} else {
			System.out.println("method = " + method + " invalid");
		}
		System.out.println("method " + method + ": minItems = " + minItems
			+ " ("+ 0.000001 * (System.nanoTime() - startTime) + " ms)");
	}

	public static void main(String[] args) {
		System.out.println("enter V and method(1 - getMinItems, " 
			+ " 2 - minItemsRecur, and 3 - minItemsDp\n");
		Scanner in = new Scanner(System.in); 
		System.out.printf("Enter V Value:  ");
		int V = in.nextInt();
		int method = 0;
		while (method <= 3) {
			System.out.printf("Enter method Value:  ");
			method = in.nextInt();
			
			test(V, method);
	    }
		in.close();
	}
}
