package ch10;

import java.util.*;
public class CheckIfArraySorted {
	static boolean arraySorted(int[] a) {
		boolean sorted = true;
		
		for (int i = 0; i < a.length - 1; i++) {
			if (a[i] > a[i + 1])
				return false;
		}
			
		return sorted;
	}
	public static void main(String[] args) {
		int[] a = {1, 8, 9, 10, 12, 15, 20, 25, 26, 36, 35};
		System.out.println("input array: " + Arrays.toString(a));
		System.out.println("arraySorted sorted: " + arraySorted(a));
	}
}
