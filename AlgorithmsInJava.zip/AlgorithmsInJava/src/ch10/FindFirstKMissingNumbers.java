package ch10;

import java.util.*;
public class FindFirstKMissingNumbers {

	static String findFirstKMissingNumbers(int[] a, int k) {
		String firstKStr = "";
		int n = a.length;
		int i = 0;
		while (i < n - 1) {
			if (a[i + 1] - a[i] >= k) {
				for (int j = 1; j <= k; j++) {
					firstKStr += a[i] + j + " ";
				}
				break;
			}
			i++;
		}

		return firstKStr;
	}
	
	public static void main(String[] args) {
		int[] a = {3, 7, 4, 12, 9, 25, 15};
		
		Arrays.sort(a);
		int k = 7;
		String firstKStr = findFirstKMissingNumbers(a, k);
		System.out.println(firstKStr);
	}
}
