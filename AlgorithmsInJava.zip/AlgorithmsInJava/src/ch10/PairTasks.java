package ch10;

import java.util.*;

public class PairTasks {
	private class Pair {
		int task1;
		int task2;
		public Pair(int task1, int task2) {
			super();
			this.task1 = task1;
			this.task2 = task2;
		}
	}

	Pair[] pairingTasks (int[] a) {
		int n = a.length;
		int numPairs = n / 2;
		Pair[] taskPairs = new Pair[numPairs];
		for (int i = 0; i < numPairs; i++)
			taskPairs[i] = new Pair(0, 0);

		Arrays.sort(a);

		for (int i = 0; i < numPairs; i++) {
			taskPairs[i].task1 = a[i];
			taskPairs[i].task2 = a[n - 1 - i];
		}
		return taskPairs;
	}

	void test1() {
		int a[] = {5, 2, 1, 6, 4, 4};
		int n = a.length;
		int numPairs = n / 2;
		Pair[] taskPairs = pairingTasks (a);
		for (int i = 0; i < numPairs; i++) {
			System.out.println(">>paired " + taskPairs[i].task1 + " with " + taskPairs[i].task2);
		}
	}

	public static void main(String[] args) {
		PairTasks pt = new PairTasks();
		pt.test1();
	}
}
