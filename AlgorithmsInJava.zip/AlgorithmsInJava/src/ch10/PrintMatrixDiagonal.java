package ch10;

public class PrintMatrixDiagonal {
	void printMatrixDiagonal (int[][] a)
	{
		int m = a.length;
		int n = a[0].length;
		System.out.println("\nm = " + m + " n = " + n);
		
		//1. lower triangle
		int i = m - 1, column = 0, j = column; // last row, first column

		while (i >= 0 && j < n)
		{
			while (j <= column)
			{
				System.out.print(a[i][j] + " ");
				i++;
				j++;
			}
			System.out.println();
			column++;
			i = m - 1 - column;
			j = 0;
		}

		// 2. upper triangle
		i = 0; column = 1; j = column; // first row, first column
		while (i < m && j < n)
		{
			while (j < n)
			{
				System.out.print(a[i][j] + " ");
				i++;
				j++;
			}
			System.out.println();
			i = 0;
			column++;
			j = column;
		}
	}

	void test1() { // 3x4
		int[][] a = {{1, 2, 3, 4},
					   {5, 6, 7, 8},
					   {9, 10, 11, 12}};

		printMatrixDiagonal(a);
	}

	void test2() { // 4x5
		int[][] a = {{1, 2, 3, 4, 5},
					   	   	   {6, 7, 8, 9, 10},
							   {11, 12, 13, 14, 15},
							   {16, 17, 18, 19, 20}};

		printMatrixDiagonal(a);
	}
	public static void main(String[] args) {
		PrintMatrixDiagonal pmd = new PrintMatrixDiagonal();
		pmd.test1();
		pmd.test2();
	}
}
