package ch10;

public class PrintMatrixDiagonal {
	void printMatrixDiagonal (int[][] a)
	{
		int m = a.length;
		int n = a[0].length;
		System.out.println("\nm = " + m + " n = " + n);
		int i = m - 1, j = 0; // last row, first column
		int level = 1;
		while (i >= 0 && j < n)
		{
			int k = j;
			while (k < level)
			{
				System.out.print(a[i][k] + " ");
				i++;
				k++;
			}
			System.out.println();
			i = m - 1 - level;
			j = 0;
			level++;
		}

		i = 0; j = 1;
		while (i < m && j < n)
		{
			int k = j;
			while (k < n)
			{
				System.out.print(a[i][k] + " ");
				i++;
				k++;
			}
			System.out.println();
			i = 0;
			j++;
		}
	}

	void test1() { // 3x4
		int[][] a = {{1, 2, 3, 4},
					   {5, 6, 7, 8},
					   {9, 10, 11, 12}};

		printMatrixDiagonal(a);
	}

	void test2() { // 4x5
		int[][] a = {{1, 2, 3, 4, 5},
					   	   	   {6, 7, 8, 9, 10},
							   {11, 12, 13, 14, 15},
							   {16, 17, 18, 19, 20}};

		printMatrixDiagonal(a);
	}
	public static void main(String[] args) {
		PrintMatrixDiagonal pmd = new PrintMatrixDiagonal();
		pmd.test1();
		pmd.test2();
	}
}
