package ch10;

import java.util.*;

public class SortByFreqency {

	public static void main(String[] args) {
		int[] a = {1, 5, 2, 5, 1, 3, 5, 2, 80, 5};
		Map<Integer, Integer>  countMap = new HashMap<Integer, Integer>();
		for (int i = 0; i < a.length; i++) {
			if (!countMap.containsKey(a[i])) {
				countMap.put(a[i], 1);
			} else {
				int count = countMap.get(a[i]) + 1;
				countMap.put(a[i], count);
			}
		}

		TreeMap<Integer, String> sortedMap = new TreeMap<Integer, String>();
		for (Integer key : countMap.keySet()) {
			int countKey = countMap.get(key);
			String indexStr = "";
			if (!sortedMap.containsKey(countKey)) {
				indexStr = Integer.toString(key);
			} else {
				indexStr = sortedMap.get(countKey) + "," + key;			
			}
			sortedMap.put(countKey, indexStr);
		}
		
		for (Integer key : sortedMap.keySet()) {
			System.out.println("count = " + key + " for elements: " + sortedMap.get(key));
		}
	}
	
}
