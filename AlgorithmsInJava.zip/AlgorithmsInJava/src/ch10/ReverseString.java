package ch10;

public class ReverseString {
	
	static char swapChar(char... args) {
        return args[0];
    }
	
	public static void main(String[] args) {
		String str = "This is a test";
		char[] charArr = str.toCharArray();
		int n = charArr.length;
		for (int i = 0; i < n / 2; i++) {
			charArr[i] = swapChar(charArr[n - 1 - i], charArr[n - 1 - i] = charArr[i]);
		}
		
		String newStr = String.valueOf(charArr);
		System.out.println(newStr);
	}
}
