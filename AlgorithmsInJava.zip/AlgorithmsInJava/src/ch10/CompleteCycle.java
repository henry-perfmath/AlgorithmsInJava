package ch10;

public class CompleteCycle {
	
	static boolean hasCompleteCircle (int[] a) {
		int n = a.length;
		int index = 0, count = 0;
		while (count < n) {
			index += a[count];
			//index = ((index % n) + n) % n;
			while (index < 0) {
				index = (index + n) % n;
			}
			count++;
		}

		return (index % n) == 0;
	}

	public static void main(String[] args) {
		int[] a = {3, 2, 5, -3, 10, 7, 8};
		System.out.println("test a: hasCompleteCircle = " + hasCompleteCircle(a));

		int[] b = {2, 2, -1};
		System.out.println("test b: hasCompleteCircle = " + hasCompleteCircle(b));
			
		int[] c = {3, 2, 5, -3, 10, 7, 8, 2, 2, -1};
		System.out.println("test c: hasCompleteCircle = " + hasCompleteCircle(c));
		
		int[] d = {2, 2, 0};
		System.out.println("test d: hasCompleteCircle = " + hasCompleteCircle(d));	
	}
}
