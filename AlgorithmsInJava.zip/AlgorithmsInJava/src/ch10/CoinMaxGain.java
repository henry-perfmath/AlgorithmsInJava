package ch10;

public class CoinMaxGain {

	int maxminStrategy(int[] a)
	{
		int n = a.length;
		int[][] maxGain = new int[n][n];
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++) {
				maxGain[i][j] = (i == j) ? a[i] : 0;
			}

		for (int seqEnd = 1; seqEnd < n; ++seqEnd) {
			for (int i = 0, j = seqEnd; i < n - 2 && j < n; ++i, ++j) {
				int min1 = a[i] + Math.min(maxGain[i + 2][j], maxGain[i + 1][j - 1]);
				int min2 = a[j];
				if (j >= 2)
					min2 += Math.min(maxGain[i + 1][j - 1], maxGain[i][j - 2]);
				maxGain[i][j] = Math.max(min1, min2);
				print(seqEnd, i, j, a[i], a[j], maxGain[i][j]);
				
			}
		}
		return maxGain[0][n - 1];
	}

	void print (int seqEnd, int i, int j, int ai, int aj, int maxGain) {
		System.out.println("seqEnd = " + seqEnd + ", i = " + i + ", j = " + j
			+ ",a[" + i + "] = " + ai + ",a[" + j + "] = " + aj
			+ ",table[" + i + "][" + j + "] = " + maxGain);
	}
	void test1() {
		int a[] = { 10, 25, 1, 5};
		System.out.println("test1: maxGain = " + maxminStrategy(a));

	}
	public static void main(String[] args) {
		CoinMaxGain cmg = new CoinMaxGain();
		cmg.test1();
	}
}
