package ch10;

public class ReverseDigits {

	static int reverse (int x) {
		int result = 0;
		int remaining = Math.abs(x);
		
		while(remaining > 0) {
			// 1. shift current result to left and add last digit
			result = result * 10 + remaining % 10;
			//2. remove last digit
			remaining /= 10;
		}
		
		return x < 0 ? -result : result;
	}
	
	public static void main(String[] args) {
		System.out.println("-413 is reversedto: " + reverse(-413));
	}
}
