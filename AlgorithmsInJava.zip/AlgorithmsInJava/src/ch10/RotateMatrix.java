package ch10;

public class RotateMatrix {
	static void rotateMatrix(int offset, int n, int[][] a) {
		if ((n % 2 == 0 || n % 2 == 1) && offset >= n / 2)
			return;

		// save last column
		int[] tmp = new int[n - offset];
		for (int i = offset; i < n - offset; i++)
			tmp[i - offset] = a[i][n - 1 - offset];

		// rotate 1st row to last column
		for (int j = n - 1 - offset; j >= offset; j--)
			a[j][n - offset - 1] = a[offset][j];

		// rotate 1st column to 1st row
		for (int i = offset; i < n - offset; i++)
			a[offset][n - 1 - i] = a[i][offset];
		
		// rotate last row to 1st column
		for (int j = offset; j < n - offset; j++)
			a[j][offset] = a[n - 1 - offset][j];

		// rotate last column to last row
		for (int i = n - 1 - offset; i > offset; i--)
			a[n - 1 - offset][n - 1 - i] = tmp[i - offset];
		offset++;
		rotateMatrix(offset, n, a);
	}
	

	static void printMatrix(int n, int[][] a) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				System.out.print(a[i][j] + " ");
			System.out.println();
		}
	}
	static void test1() {
		int n = 3;
		int[][] a = {{1, 2, 3}, {4, 5, 6}, {7,8, 9}};
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				System.out.print(a[i][j] + " ");
		System.out.println();
		rotateMatrix(0, n, a);
		printMatrix(n, a);
	}
	static void test2() {
		int n = 4;
		int[][] a = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}, {13, 14, 15, 16}};
		System.out.println();
		
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				System.out.print(a[i][j] + " ");
		System.out.println();
		rotateMatrix(0,n, a);
		printMatrix(n, a);
	}

	public static void main(String[] args) {
		test1();
		test2();
	}
}
