package ch8;

public class BST {
	Node root;
	int size;
	public BST() {
		super();
	}

	Node insertRecur(Node root, int key) {
		if (root == null) {
			root = new Node(key);
		} else if (key < root.key) {
			root.left = insertRecur(root.left, key);
		} else if (key > root.key) {
			root.right = insertRecur(root.right, key);
		}
		
		return root;
	}

	Node insertIter(Node root, int key) {
		Node node = new Node(key);
		Node parent = null;

		Node cursor = root;
		while (cursor != null) {
			parent = cursor;
			if (key < cursor.key) {
				cursor = cursor.left;
			} else if (key > cursor.key) {
				cursor = cursor.right;
			}
		}
		
		System.out.println("insert " + key);
		if (parent == null) {
			parent = node;
		} else if (key < parent.key) {
			parent.left = node;
		} else if (key > parent.key) {
			parent.right = node;
		}

		return parent;
	}
	
	void inorder(Node node) {
		if (node != null) {
			inorder(node.left);
			System.out.print(node.key + " ");
			inorder(node.right);
		}
	}
	
	void preorder(Node node) {
		if (node != null) {
			System.out.print(node.key + " ");
			inorder(node.left);
			inorder(node.right);
		}
	}
	
	void postorder(Node node) {
		if (node != null) {
			inorder(node.left);
			inorder(node.right);
			System.out.print(node.key + " ");
		}
	}
	
	void clear (Node node) {
		if (node != null) {
			clear(node.left);
			clear(node.right);
		}
	}
}
