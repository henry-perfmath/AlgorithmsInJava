package ch8;

public class BFT {
	Node root;
	int size;
	public BFT() {
		super();
	}
	
	//1. find treeLevels with a given node
	static int treeLevels(Node node) {
		if (node == null)
			return 0;
		else return 1 + Math.max(treeLevels(node.left), treeLevels(node.right));
	}
	
	//2. printLevel with a given node
	static void printLevel(Node node, int level) {
		if (node == null)
			return;
		
		if (level == 1)  {
			System.out.print(node.key + " ");
		} else if (level > 1) {
			printLevel(node.left, level - 1);
			printLevel(node.right, level - 1);
		}
	}
	
	static void bft(Node node) {
		int numLevels = treeLevels(node);
		for (int i = 1; i <= numLevels; i++) {
			printLevel(node, i);
		}
	}
	
	public static void main(String[] args) {
		Node root = null;
		BST bst = new BST();
		root = bst.insertIter(root, 50);
		
		bst.insertIter(root, 30);
		bst.insertIter(root, 20);
		bst.insertIter(root, 40);
		bst.insertIter(root, 70);
		bst.insertIter(root, 60);
		bst.insertIter(root, 80);
		
		System.out.print("inorder: ");
		bst.inorder(root);
		
		System.out.print("\npreorder: ");
		bst.preorder(root);
		
		System.out.print("\npostorder: ");
		bst.postorder(root);
		
		System.out.print("\nbft: ");
		bft(root);
		System.out.println("\nclear ... ");
		
		bst.clear(root);
	}
}
