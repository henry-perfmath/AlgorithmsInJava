package ch8;
import java.util.*;
public class QueueBasedBFT {
	static void bft(Node root) {
		Queue<Node> queue = new LinkedList<Node>();
		Node node = root;

		queue.add(node);
		while (queue.size() > 0) {
			node = queue.remove();
			System.out.print(node.key + "(" + queue.size() + ") ");
			if (node.left != null) {
				queue.add(node.getLeft());
			}
			if (node.right != null) {
				queue.add(node.getRight());
			}
		}
	}
	
	public static void main(String[] args) {
		Node root = null;
		BST bst = new BST();
		root = new Node(50);
		//root = bst.insert(root, 50);
		
		bst.insertIter(root, 30);
		bst.insertIter(root, 20);
		bst.insertIter(root, 40);
		bst.insertIter(root, 70);
		bst.insertIter(root, 60);
		bst.insertIter(root, 80);
		bst.insertIter(root, 15);
		bst.insertIter(root, 25);
		
		System.out.print("inorder: ");
		bst.inorder(root);
		
		System.out.print("\npreorder: ");
		bst.preorder(root);
		
		System.out.print("\npostorder: ");
		bst.postorder(root);
		
		System.out.print("\nqueue-based bft: ");
		bft(root);
		System.out.println("\nclear ... ");
		
		bst.clear(root);
	}
}
