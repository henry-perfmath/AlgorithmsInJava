package ch8;

import java.util.Arrays;
import java.util.Random;

public class Heap {

	private static int log2(int x) {
	    return (int) (Math.log(x) / Math.log(2.0));
	}
	
	//usage: a = swap(b, b = a);
	public static int swap(int... args) {
        return args[0];
    }

	static void maxHeapSort (int[] a, int n) {
		buildMaxHeap(a, n);
		for (int i = n - 1; i >0; --i) {
			a[0] = swap(a[i], a[i] = a[0]);
			--n;
			maxPercDown(a, n, 0);
		}
	}

	static void minHeapSort (int[] a, int n) {
		buildMinHeap(a, n);
		for (int i = n - 1; i > 0; --i) {
			a[i] = swap(a[0], a[0] = a[i]);
			--n;
			minPercDown(a, n, 0);
		}
	}
	
	static void buildMaxHeap (int[] a, int n) {
		for (int pIdx = n / 2 - 1; pIdx >= 0; --pIdx) {
			maxPercDown(a, n, pIdx);
		}
	}
	
	static void buildMinHeap(int[] a, int n) {
		for (int pIdx = n / 2 - 1; pIdx >= 0; --pIdx) {
			minPercDown(a, n, pIdx);
		};
	}

	static void maxPercDown(int[] a, int n, int pIdx) {
		int largest = pIdx;
		int cIdx = 2 * pIdx + 1;
	
		if (cIdx < n && a[cIdx] > a[pIdx]) {
			largest = cIdx;
		}
		
		int largerCIdx = cIdx + 1;
		if(largerCIdx < n && a[largerCIdx] > a[largest])
			largest = largerCIdx;
		
		if (largest != pIdx) {
			a[pIdx] = swap(a[largest], a[largest] = a[pIdx]);
			maxPercDown(a, n, largest);
		}
	}
	
	static void minPercDown(int[] a, int n, int pIdx) {
		// Weiss p. 262
		int pItem = a[pIdx];

		// should not be "<"
		while(pIdx <= (n - 1) / 2) {
			// left child within heap
			int cIdx = 2 * pIdx + 1;
			if ((cIdx + 1) < n && a[cIdx + 1] < a[cIdx])
				cIdx++;
			if(pItem > a[cIdx]) {
				a[pIdx] = a[cIdx];
			} else 
				break;
			pIdx = cIdx;
		}
		a[pIdx] = pItem;
	}

	// add x to existing array and return a new array
	static int[] newArray(int[] a, int x) {
		int n = a.length;
		int[] aNew = new int[n + 1];

		for (int i = 0; i < n; i++) {
			aNew[i] = a[i];
		}
		
		aNew[n] = x;
		
		printHeap("before inserting 15\n ", aNew, n + 1);
		return aNew;
	}
	
	static int[] minInsert (int[] a, int n, int x) {
		int[] aNew = newArray(a, x);
		n = aNew.length;
		buildMinHeap(aNew, n);
		printHeap("after minInsert 15\n ", aNew, n);
		return aNew;
	}
	
	static int deleteMin (int[]a, int n) {
		int minVal = a[0];
		a[0] = a[n - 1];
		--n;
		buildMinHeap(a, n);
		return minVal;
	}
	
	static void printHeap(String header, int[] a, int n) {
		System.out.print("\n" + header);
		int level = 0;
		for (int i = 0; i < n; i++) {
			int l = log2(i + 1);
			if (l > level) {
				System.out.print("\n ");
				level = l;
			} else if (l < level){
				System.out.print("\n " + l + " < " + level + " \n");
			}
			System.out.print(a[i] + " ");
		}
		System.out.print("\n");
	}
	
	static void test3() {
		int n = 1000000;
		int[] a = new int[n];
		
		Random rndm = new Random();
		for (int i = 0; i < n; i++) {
			a[i] = rndm.nextInt() % (2 * n);
		}
		long startTime = System.currentTimeMillis();
		maxHeapSort(a, n);
		System.out.println("total time (seconds) = " + 
		 (System.currentTimeMillis() - startTime));
	}
	
	static void test2() {
		int n = 1000000;
		int[] a = new int[n];
		
		Random rndm = new Random();
		for (int i = 0; i < n; i++) {
			a[i] = rndm.nextInt() % (2 * n);
		}
		long startTime = System.currentTimeMillis();
		minHeapSort(a, n);
		System.out.println("total time (ms) = " + 
				 (System.currentTimeMillis() - startTime));
	}
	
	static void test1() {
		int[] a = {150, 80, 40, 30, 60, 70,110, 100, 20, 90, 10, 50, 120, 140, 130};
		int n = a.length;
		
		printHeap("before buildMinHeap\n ", a, n);
		buildMinHeap(a, n);		
		printHeap("after buildMinHeap\n ", a, n);
		
		System.out.println("\n=====");
		System.out.println("a: " + Arrays.toString(a));

		int[] b = minInsert(a, n, 15);
		printHeap("after inserting 15\n ", b, n + 1);
		int minVal = deleteMin(a, n);
		System.out.println("\ndeleteMin: minVal = " + minVal);
		printHeap("after deleteMin:\n ", a, n);
		
		printHeap("before minHeapSort:\n ", a, n);
		minHeapSort(a, n);
		printHeap("after minHeapSort:\n ", a, n);
	}
	
	static void test0() {
		int[] a = {150, 80, 40, 30, 60, 70,110, 100, 20, 90, 10, 50, 120, 140, 130, 15};
		int n = a.length;
		
		printHeap("before maxHeapSort:\n ", a, n);	
		maxHeapSort(a, n);
		printHeap("after maxHeapSort:\n ", a, n);
		
		printHeap("before minHeapSort:\n ", a, n);		
		minHeapSort(a, n);
		printHeap("after minHeapSort:\n ", a, n);
	}
	public static void main(String[] args) {
		System.out.println("test0: test maxHeapSort");
		test0();
		
		System.out.println("\ntest1: test minHeap build, insert and sort");
		test1();
		
		System.out.println("\ntest2: test minHeap sort with 1M integers");
		test2();
		
		System.out.println("\ntest3: test maxHeap sort with 1M integers");
		test3();
	}
}
