package ch8;

public class CommonAncestor {
	static int findCommonAncestor(Node root, int leftKey, int rightKey) {
		Node cursor = root;
		while (cursor != null) {
			int currKey = cursor.key;
			if (currKey > leftKey && currKey > rightKey) {
				cursor = cursor.left;
			} else if (currKey < leftKey && currKey < rightKey){
				cursor = cursor.right;
			} else {
				return currKey;
			}
		}
		return -1; // not found
	}
	// 1. iterative
	static void test1() {
		BST bst = new BST();
		Node root = null;
		root = bst.insertIter(root, 50);
		bst.insertIter(root, 30);
		bst.insertIter(root, 20);
		bst.insertIter(root, 40);
		bst.insertIter(root, 70);
		bst.insertIter(root, 60);
		bst.insertIter(root, 80);
		bst.insertIter(root, 10);
		bst.insertIter(root, 25);
		bst.insertIter(root, 35);
		bst.insertIter(root, 45);
		
		bst.preorder(root);
		
		int commonAncestor = findCommonAncestor(root, 25, 35);
		System.out.println("Found common ancessator (-1 means not found): " +
		commonAncestor);
	}
	
	// 2. recursive
	static void test2() {
		BST bst = new BST();
		Node root = null;
		root = bst.insert(root, 50);
		bst.insert(root, 30);
		bst.insert(root, 20);
		bst.insert(root, 40);
		bst.insert(root, 70);
		bst.insert(root, 60);
		bst.insert(root, 80);
		bst.insert(root, 10);
		bst.insert(root, 25);
		bst.insert(root, 35);
		bst.insert(root, 45);
		
		bst.preorder(root);
		
		int commonAncestor = findCommonAncestor(root, 25, 35);
		System.out.println("Found common ancessator (-1 means not found): " +
		commonAncestor);
	}
	public static void main(String[] args) {
		test1();
		test2();
	}
}
